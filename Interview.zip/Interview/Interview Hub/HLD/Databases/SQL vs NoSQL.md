---
tags: [hld, databases]
difficulty: medium
status: not-started
confidence: 0/5
---
# SQL vs NoSQL

This decision comes up in almost every system design interview, and the weak answer is "NoSQL scales better so I'll use that." The strong answer ties the choice to your actual data shape and access patterns, not a vague notion of "scale."

**SQL (relational)** gives you a fixed schema, joins across tables, and — critically — [[ACID]] transactions. Reach for it when: your data has real relationships you'll query across (orders → users → products), you need multi-row transactions to be atomic (moving money, booking a seat), or your access patterns aren't fully known yet and you want the flexibility of ad-hoc queries. The scaling story is real but it's not "impossible" — read replicas and [[Database Scaling|sharding]] get you a long way, it's just more manual work than most NoSQL stores.

**NoSQL** isn't one thing — it's a family, and naming the right sub-type is what makes an answer sound informed instead of memorized:
- **Key-value** (Redis, DynamoDB): O(1) lookups by key, extremely fast, minimal query flexibility. Great for caching, session storage, or any "get by ID" heavy workload.
- **Document** (MongoDB): JSON-like documents, flexible schema, good when your data is naturally nested and you mostly query by document ID or a few indexed fields (e.g., a product catalog with wildly varying attributes per category).
- **Wide-column** (Cassandra, Bigtable): built for massive write throughput and horizontal scale, models data around your query patterns rather than normalized relations. Good for time-series or event data at huge scale.
- **Graph** (Neo4j): when relationships *are* the data — social graphs, recommendation engines.

My actual decision process out loud: "What are the relationships in this data, and do I need multi-row transactions?" → if yes, lean SQL. "Do I know my query patterns up front and need to scale writes horizontally past what a single primary can do?" → lean NoSQL, and pick the sub-type based on shape (key-value for simple lookups, document for nested/flexible objects, wide-column for time-series/huge write volume).

It's also completely fine — and often the strongest answer — to say "I'd use both": SQL for the transactional core (orders, payments) and a NoSQL store for a specific hot path (session cache, activity feed).

## Key points
- SQL: fixed schema, joins, [[ACID]] transactions — pick when relationships and multi-row atomicity matter.
- NoSQL is a family, not one thing: key-value (fast lookups), document (flexible/nested), wide-column (massive write scale), graph (relationship-heavy data).
- Real scaling difference: SQL scales with more manual work (replicas, [[Database Scaling|sharding]]); many NoSQL stores scale horizontally more natively.
- Strongest answers often use both — polyglot persistence, not a single store for the whole system.
- Tie every choice to actual access patterns, never say "NoSQL because scale" without naming the sub-type and why.

## Related
- [[ACID]]
- [[Database Scaling]]
- [[Database Sharding]]
- [[Database Indexing]]
