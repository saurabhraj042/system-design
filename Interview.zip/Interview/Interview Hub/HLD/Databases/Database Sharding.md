---
tags: [hld, databases]
difficulty: hard
status: not-started
confidence: 0/5
---
# Database Sharding

Sharding is splitting one logical database into multiple physical databases, each holding a subset of the data, so you can scale writes horizontally past what a single machine can handle. This is the answer to "what do you do when read replicas aren't enough" — replicas solve read scaling, sharding solves write scaling (and total storage size).

The whole game in a sharding question is picking the **shard key** — the field you hash or range-partition on to decide which shard a row lives on. Get this wrong and you get a "hot shard" (one shard doing way more work than the others) or you make common queries need to fan out across every shard, which kills the point of sharding in the first place.

**Sharding strategies:**
- **Range-based**: shard by ranges of the key (e.g., user IDs 1-1M on shard 1, 1M-2M on shard 2). Simple, but easy to create hot shards if writes concentrate in one range (e.g., IDs are sequential and all new users hit the newest shard).
- **Hash-based**: `hash(shard_key) % N`. Spreads load evenly, but — same problem as naive cache distribution — adding a shard means reshuffling almost everything. This is exactly where [[Consistent Hashing]] applies to databases too, not just caches.
- **Directory-based**: a lookup service maps each key to its shard explicitly. Most flexible (easy to rebalance), but the lookup service itself becomes a critical dependency and potential bottleneck.

**The real cost of sharding**, which I always state up front because it's the actual tradeoff being tested: cross-shard joins and transactions become hard or impossible. If you shard orders by `user_id`, "find all orders for product X across all users" now means querying every shard and merging results. This is why I treat sharding as a last resort after read replicas, caching, and indexing — it's powerful but it fundamentally changes what queries are cheap.

Picking the shard key in an interview: I ask "what's the most common query pattern?" and shard on that field so the common case stays single-shard. For a chat app, that's `conversation_id`; for a booking system, arguably `region` or `venue_id`.

## Key points
- Sharding = splitting data across multiple databases to scale writes/storage horizontally, past what replicas alone can do.
- Shard key choice is the whole ballgame — pick it based on your most common query pattern to keep that query single-shard.
- Strategies: range-based (simple, hot-shard risk), hash-based (even, uses [[Consistent Hashing]], resharding is costly without it), directory-based (flexible, adds a dependency).
- Real cost: cross-shard joins/transactions become hard — this is the tradeoff to name explicitly, not just "it scales."
- Treat as a last resort after replicas + caching + indexing, since it changes what's cheap to query.

## Related
- [[Consistent Hashing]]
- [[Database Replication]]
- [[Database Scaling]]
- [[SQL vs NoSQL]]
