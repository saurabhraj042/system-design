---
tags: [hld, databases]
difficulty: medium
status: not-started
confidence: 0/5
---
# Database Scaling

This note is the decision tree — the order I actually walk through when a database is becoming a bottleneck in a system design interview, before jumping straight to "let's shard it" (which is usually not the first or even second move).

**Step 1 — Indexing.** Before anything else: is the slow query actually indexed properly? See [[Database Indexing]]. An unindexed query on a small dataset looks fine in a demo and falls over at real scale — this is the cheapest fix and I check it first, out loud, every time.

**Step 2 — Caching.** Can I avoid hitting the database at all for the hottest reads? See [[Caching Strategies]]. If 90% of reads are for a small set of hot rows (a trending post, a popular product), a cache in front of the database removes almost all that load without touching the database architecture at all.

**Step 3 — Read replicas.** If reads (not writes) are the bottleneck and caching alone isn't enough, add [[Database Replication|read replicas]] and route reads to them, keeping writes on the primary. This is "vertical-ish" scaling of read capacity without touching your data model.

**Step 4 — Vertical scaling.** Sometimes the honest answer is "give the database a bigger machine" (more CPU/RAM/faster disk) — see [[Horizontal vs Vertical Scaling]]. It's boring but it's real, has zero architectural complexity cost, and I mention it explicitly so the interviewer knows I'm not scaling-hammer-happy — I only reach for sharding when vertical scaling has a real ceiling (and it does, eventually).

**Step 5 — Sharding.** Only once writes themselves need to scale past a single primary, or the dataset is too large for one machine even with a bigger box — see [[Database Sharding]]. This is the most complex, most disruptive option (cross-shard joins/transactions get hard), so it's the last resort, not the first instinct.

Saying this order out loud in an interview — "first I'd check indexing, then caching, then read replicas, then only shard if writes are the actual bottleneck" — signals real production experience much more than jumping straight to sharding because it's the "advanced" answer.

## Key points
- Order of operations: indexing → caching → read replicas → vertical scaling → sharding. State this order explicitly.
- Indexing and caching solve the vast majority of real bottlenecks without touching the data architecture at all.
- Read replicas scale reads; sharding scales writes and total storage — know which problem you actually have before picking a fix.
- Vertical scaling is a legitimate, low-complexity step — don't skip past it straight to sharding.
- Sharding is the last resort because it fundamentally changes what queries are cheap (cross-shard joins/transactions).

## Related
- [[Database Indexing]]
- [[Caching Strategies]]
- [[Database Replication]]
- [[Database Sharding]]
- [[Horizontal vs Vertical Scaling]]
