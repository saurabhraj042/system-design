---
tags: [hld, databases]
difficulty: medium
status: not-started
confidence: 0/5
---
# Database Replication

Replication means keeping copies of your data on multiple database nodes, for two reasons that are worth naming separately: **read scaling** (spread read load across replicas so the primary isn't doing all the work) and **fault tolerance** (if the primary dies, a replica can take over instead of the whole system going down). Almost every real production database has replication before it has sharding — it's the first scaling lever, not the last.

**Primary-replica (master-slave)**: all writes go to the primary, which streams changes to one or more replicas. Reads can be served from either, but replicas lag behind the primary by some amount (**replication lag**) because the replication is asynchronous in most setups. This is *the* practical source of eventual consistency in real systems — "I just wrote this and then read it back from a replica and it's not there yet" is a replication lag bug, not a mystery.

**Synchronous vs asynchronous replication**: synchronous means the primary waits for the replica to confirm before acknowledging the write — zero data loss on failover, but higher write latency (and if a replica is slow, it drags the primary down). Asynchronous means the primary acknowledges immediately and replicates in the background — fast writes, but a crash right after a write can lose data that never made it to a replica. Most systems use async for the throughput win and accept the small data-loss risk, and semi-sync (wait for at least one replica) is a common middle ground.

**Failover**: when the primary dies, something has to promote a replica to be the new primary — this is either automatic (via a consensus tool or managed service) or manual. I mention this explicitly when [[Availability]] comes up, because "we have replicas" doesn't automatically mean "we auto-recover from a primary failure" — you need failover logic too.

**Multi-primary (master-master)**: multiple nodes accept writes, and conflicts have to be resolved somehow (last-write-wins, vector clocks, application-level merge logic). This is powerful for multi-region writes but genuinely complex — I only reach for it when a design explicitly needs writes accepted in multiple regions simultaneously.

## Key points
- Two goals: read scaling (offload reads to replicas) and fault tolerance (failover if primary dies) — name both.
- Primary-replica is the default: writes to primary, reads from either, replication lag causes real eventual consistency.
- Sync replication = safer, slower writes; async = faster, small data-loss risk on crash — most systems pick async.
- Failover (promoting a replica) needs explicit handling — replicas alone don't give you auto-recovery.
- Multi-primary enables multi-region writes but needs conflict resolution — reach for it only when truly needed.

## Related
- [[Availability]]
- [[Consistency]]
- [[CAP Theorem]]
- [[Database Sharding]]
