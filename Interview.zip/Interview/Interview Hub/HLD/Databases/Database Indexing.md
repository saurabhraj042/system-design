---
tags: [hld, databases]
difficulty: medium
status: not-started
confidence: 0/5
---
# Database Indexing

An index is a separate data structure (almost always a B-tree, sometimes a hash index) that lets the database find rows without scanning the whole table. Without an index on a column, `WHERE email = 'x'` means checking every single row — O(n). With an index, it's roughly O(log n). This is the fastest, cheapest performance win in almost any system design that involves a database, and I bring it up before reaching for caching or sharding whenever the bottleneck is "a specific query is slow."

The tradeoff that's actually worth stating (not just "indexes make reads fast"): every index you add makes writes slower, because the index itself has to be updated on every insert/update/delete, and it takes extra disk space. So indexing isn't "always add more" — it's "index the columns you actually filter/sort/join on, and no more than that."

**What to index**, in the order I actually think about it:
- Columns in `WHERE` clauses, especially ones used constantly (a `user_id` foreign key, an `email` for login lookups).
- Columns used in `JOIN` conditions.
- Columns used in `ORDER BY` — an index can let the database skip a separate sort step entirely.
- **Composite indexes** (multiple columns in one index) when queries filter on more than one column together — order matters, the index is only useful as a left-prefix (an index on `(user_id, created_at)` helps `WHERE user_id = ?` and `WHERE user_id = ? AND created_at > ?`, but not `WHERE created_at > ?` alone).

**B-tree vs hash index**: B-tree is the default — it supports range queries (`>`, `<`, `BETWEEN`) and sorted order, which is what most queries need. Hash indexes are O(1) but only support exact-match equality, no ranges — fine for a pure key-value lookup, wrong choice the moment someone wants `ORDER BY` or a range filter.

I always connect this back to the actual query pattern in the design: if I've just said "we'll query orders by user and date range," my very next sentence is "so I'd put a composite index on `(user_id, created_at)`."

## Key points
- Index = separate structure (usually B-tree) enabling O(log n) lookups instead of O(n) full scans.
- Cost: every index slows down writes and uses extra storage — index deliberately, not exhaustively.
- Index columns used in `WHERE`, `JOIN`, and `ORDER BY` — that's the practical checklist.
- Composite indexes are left-prefix only — column order in the index definition matters.
- B-tree (default, supports ranges/sorting) vs hash index (O(1) but equality-only, no ranges).
- Always tie the index choice back to the specific query pattern you just described in the design.

## Related
- [[SQL vs NoSQL]]
- [[Database Scaling]]
- [[Latency]]
