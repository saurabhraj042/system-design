---
tags: [hld, caching]
difficulty: medium
status: not-started
confidence: 0/5
---
# Write-Through

Write-through caching means every write goes to the cache *and* the database synchronously, as a single logical operation, before the write is considered complete. The upside is obvious: the cache is never stale, because nothing gets written to the DB without also landing in the cache at the same moment.

I reach for this when the cost of serving stale data is higher than the cost of slightly slower writes — think a shopping cart, an account settings page, or anything where "the user just changed X and immediately sees the old X" would look broken or feel untrustworthy. The tradeoff is straightforward: writes get slower because you're doing two synchronous operations instead of one, and if the cache is momentarily unavailable you have to decide whether to fail the write or fall back to DB-only.

Where I make sure to distinguish this from [[Write-Back]] in an interview: write-through is safe (durable immediately, in both places) but slower on writes; write-back is fast on writes but risks data loss if the cache dies before it flushes to the database. That single sentence usually satisfies an interviewer probing "why not just always write-back."

Combined with cache-aside for reads, write-through gives you a system where reads are fast (served from cache) and writes are always consistent between cache and DB — a very common combo for things like user profile data.

## Key points
- Every write updates cache + database together, synchronously — cache is never stale after a write.
- Slower writes (two operations) in exchange for read consistency.
- Good fit: data where staleness is unacceptable but read speed still matters (account settings, cart contents).
- Contrast directly with [[Write-Back]] (async, faster, riskier) when asked to justify the choice.
- Often paired with [[Cache-Aside]] reads — write-through for writes, cache-aside for reads is a common real-world combo.

## Related
- [[Caching Strategies]]
- [[Cache-Aside]]
- [[Write-Back]]
- [[Consistency]]
