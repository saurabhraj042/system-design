---
tags: [hld, caching]
difficulty: hard
status: not-started
confidence: 0/5
---
# Consistent Hashing

Consistent hashing solves one specific, very common interview problem: how do you distribute keys across a set of nodes (cache servers, database shards) such that adding or removing a node only remaps a small fraction of keys, instead of almost all of them?

Start with why naive hashing fails, because that's the setup that makes consistent hashing click: with `hash(key) % N`, if you go from 4 nodes to 5, the modulus changes for nearly every key, so nearly every key now maps to a different node. For a cache, that's a stampede of misses; for a sharded database, that's a massive, expensive rebalancing.

The actual technique: imagine a ring (0 to 2^32-1, wrapping around). Hash each node onto a position on this ring. To find which node owns a key, hash the key and walk clockwise until you hit a node. When you add a node, it only takes ownership of the keys between it and the previous node on the ring — everything else is untouched. When a node is removed, only its keys move to the next node clockwise. Roughly `1/N` of keys move on any change instead of nearly all of them.

The practical wrinkle I always mention: with only a few points per node on the ring, load can be very uneven (one node might own a huge arc, another a tiny sliver). The fix is **virtual nodes** — each physical node gets hashed to many points on the ring (e.g., 100-200 virtual nodes per physical node), which smooths out the load distribution a lot. If I say "consistent hashing" without mentioning virtual nodes, I consider the answer incomplete for a mid/senior-level bar.

## Key points
- Solves: minimizing key remapping when nodes are added/removed in a [[Distributed Caching|distributed cache]] or sharded database.
- Naive `hash(key) % N` remaps almost everything on a node count change — this is the "why" you should state before the "what."
- Ring structure: hash nodes and keys onto the same circular space, key belongs to the next node clockwise.
- Only ~`1/N` of keys move on a node add/remove, not nearly all of them.
- **Virtual nodes** fix uneven load distribution — always mention this, it's the detail that separates a memorized answer from an understood one.
- Real-world use: DynamoDB, Cassandra (partitioning), Redis Cluster, CDN request routing, load balancers.

## Related
- [[Distributed Caching]]
- [[Database Scaling]]
- [[Load Balancing Basics]]
- [[Chat Application]]
