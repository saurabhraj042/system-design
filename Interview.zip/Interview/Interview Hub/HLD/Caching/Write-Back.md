---
tags: [hld, caching]
difficulty: medium
status: not-started
confidence: 0/5
---
# Write-Back

Write-back (a.k.a. write-behind) caching means a write only goes to the cache immediately — the database write is deferred and happens asynchronously later, usually batched. This makes writes extremely fast from the caller's perspective, because you're not waiting on a database round-trip at all.

The obvious catch, and the thing I always say out loud before an interviewer can ask "but what if the cache crashes": if the cache node dies before the deferred write flushes to the database, that data is gone. So write-back is a genuine durability-vs-speed tradeoff, not a free lunch. It's the right call when write volume is very high and you can tolerate some risk of loss (analytics events, view counters, telemetry) — much less appropriate for anything financial or anything a user would consider "their data."

I like to bring up **batching** as the actual reason write-back exists beyond raw speed: instead of hitting the database with 1,000 individual writes, you can coalesce them into fewer, larger writes (e.g., "increment view count by 47" instead of 47 separate "+1" writes). That's a real throughput win, not just a latency trick.

In an interview, if someone asks me to design a view-counter or like-counter at scale, write-back plus periodic flush-to-DB is exactly the pattern I reach for — it's a very "I've actually thought about this" answer.

## Key points
- Write hits the cache immediately, database write is deferred and async — very fast writes.
- Risk: data loss if the cache fails before flushing to the database — explicitly call this out unprompted.
- Enables **batching/coalescing** writes for a real throughput win, not just lower latency.
- Good fit: high-volume, loss-tolerant writes — view counts, likes, telemetry/analytics events.
- Bad fit: anything requiring durability guarantees (payments, bookings) — use [[Write-Through]] or skip caching there.

## Related
- [[Caching Strategies]]
- [[Write-Through]]
- [[Throughput]]
- [[Consistency]]
