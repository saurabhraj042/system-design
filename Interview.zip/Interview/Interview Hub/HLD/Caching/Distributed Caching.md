---
tags: [hld, caching]
difficulty: medium
status: not-started
confidence: 0/5
---
# Distributed Caching

A distributed cache is what you get when a single cache node (like one Redis instance) can't hold all your hot data or can't handle your read throughput alone, so you spread the cache across multiple nodes. This comes up the moment your system design answer scales past "toy" size — if you're designing something meant to serve millions of users, a single-node cache is a bottleneck and a single point of failure, and interviewers expect you to notice that yourself.

The core problem distributed caching introduces: **given a key, which node holds it?** The naive answer — `hash(key) % number_of_nodes` — works until you add or remove a node, at which point almost every key remaps to a different node and you get a massive cache miss storm right when you're trying to scale. This is exactly the problem [[Consistent Hashing]] solves, and it's the single most-tested concept in this whole folder — if an interviewer asks anything about scaling a cache, they're fishing for consistent hashing.

Beyond the hashing scheme, distributed caches raise the same questions as any distributed data store: replication (do you keep 2-3 copies of each key for fault tolerance?), and what happens on a node failure (do requests fail, or does the client transparently retry against the next node in the ring?). Real systems like Redis Cluster and Memcached with a consistent-hashing client library handle this for you, and it's fine to namedrop them as "I'd use Redis Cluster here" rather than building the ring by hand.

## Key points
- Needed once a single cache node can't hold the working set or can't handle the read QPS.
- Core problem: routing a key to the right node without a full remap every time nodes change — solved by [[Consistent Hashing]].
- Naive `hash(key) % N` breaks badly on scale up/down — always mention this before proposing consistent hashing, it shows you understand *why*, not just *what*.
- Real-world tools: Redis Cluster, Memcached + client-side consistent hashing (e.g., ketama).
- Also inherits distributed-systems concerns: replication for fault tolerance, node failure handling.

## Related
- [[Consistent Hashing]]
- [[Caching Strategies]]
- [[Database Scaling]]
- [[Chat Application]]
