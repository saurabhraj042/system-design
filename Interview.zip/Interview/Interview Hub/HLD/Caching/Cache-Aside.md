---
tags: [hld, caching]
difficulty: easy
status: not-started
confidence: 0/5
---
# Cache-Aside

Cache-aside (a.k.a. "lazy loading") is the pattern where the application talks to the cache and the database separately, and the cache only fills up with data that's actually been requested. This is my default answer whenever an interviewer says "add a cache" without more specifics — it's the simplest to reason about and it naturally caches only hot data.

The flow: on a read, check the cache first. Hit? Return it, done. Miss? Go to the database, get the data, write it into the cache, then return it to the caller. On a write, you just write to the database and either invalidate (delete) the cache entry or update it directly — invalidation is usually simpler and safer than trying to keep the cache value perfectly in sync.

The failure mode I always mention proactively (because interviewers love probing here) is **cache stampede / thundering herd**: if a popular key expires and 10,000 requests hit at the same instant, they all miss the cache simultaneously and all hammer the database at once. I bring up locking (only one request repopulates the cache, others wait) or staggered/jittered TTLs as the fix — see [[Thundering Herd]] for the full writeup.

The other honest tradeoff to mention: cache-aside has a built-in inconsistency window. Right after a write invalidates the cache, the next read has to go all the way to the database (a "cold" cache), which is a small latency spike right when you least want it. That's the price for simplicity.

## Key points
- Read path: check cache → miss → read DB → populate cache → return. Hit → return directly.
- Write path: write DB → invalidate (or update) cache entry.
- Application owns the caching logic — the cache and DB don't know about each other, which keeps things simple but pushes responsibility onto your code.
- Main risk: [[Thundering Herd]] on a popular key's expiry, and a "cold" cache after invalidation.
- Good default for read-heavy workloads where brief staleness is acceptable.

## Related
- [[Caching Strategies]]
- [[Write-Through]]
- [[Thundering Herd]]
- [[URL Shortener]]
