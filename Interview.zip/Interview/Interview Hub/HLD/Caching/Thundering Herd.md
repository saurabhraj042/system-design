---
tags: [hld, caching]
difficulty: medium
status: not-started
confidence: 0/5
---
# Thundering Herd

Thundering herd (a.k.a. cache stampede) is what happens when a hot cache key expires or gets evicted, and a huge burst of concurrent requests all miss the cache at the same instant and all go hammer the database to recompute the same value simultaneously. It's a classic "the cache made things worse, not better" failure mode, and I proactively bring it up whenever I propose caching a very hot key — it shows I'm thinking about the failure mode, not just the happy path.

The scenario that makes this vivid: a celebrity's profile page is cached with a 60-second TTL. At second 60, the cache entry expires. In the next instant, 50,000 concurrent requests for that page all miss the cache and all hit the database at once, trying to regenerate the exact same value. The database, which was fine handling cached reads, now gets a spike of 50,000 identical, expensive queries simultaneously and can fall over.

Fixes I actually reach for, in order of how often I use them:
- **Locking / single-flight**: the first request to miss acquires a lock and repopulates the cache; everyone else either waits briefly for that value or gets a slightly stale value while it's being recomputed. This is the most common real fix (e.g., `singleflight` in Go, or a Redis lock).
- **Jittered TTLs**: instead of every replica of a key expiring at exactly the same second, add random jitter (e.g., TTL of 60s ± 10s) so expirations spread out instead of syncing up.
- **Probabilistic early recomputation**: refresh the cache slightly *before* it actually expires, with probability increasing as expiry approaches — so it's almost never actually cold when a real request arrives.
- **Never-expire + background refresh**: for extremely hot keys, don't let them expire at all; refresh them on a schedule in the background so user requests never race a cold cache.

## Key points
- Trigger: a hot key expires/evicts and many concurrent requests miss simultaneously, all hitting the DB at once.
- Fixes: locking/single-flight (most common), jittered TTLs, probabilistic early refresh, never-expire + background refresh for the hottest keys.
- Bring this up unprompted when caching something you've flagged as "very hot" — it's a strong signal in an interview.
- Related idea: same failure pattern can happen at the CDN layer too, not just app-level caches.

## Related
- [[Caching Strategies]]
- [[Cache-Aside]]
- [[Latency]]
- [[Rate Limiter]]
