---
tags: [hld, caching]
difficulty: medium
status: not-started
confidence: 0/5
---
# Caching Strategies

Caching is the single highest-leverage move in almost every system design interview — it's usually the first thing I reach for after nailing requirements, because it directly attacks [[Latency]] and takes load off the database, which is almost always the first thing to fall over.

This note is the map — the actual read/write patterns ([[Cache-Aside]], [[Write-Through]], [[Write-Back]]) each have their own note, but here's how I decide which one to reach for live in an interview:

**Is this read-heavy or write-heavy?** Most systems are read-heavy (way more reads than writes), which is why cache-aside is the default answer 80% of the time — it's simple, and the cache only holds what's actually being requested.

**Can I tolerate a moment of staleness?** If yes, cache-aside or write-back both work. If no (e.g., an account balance), you need write-through or you skip caching for that data entirely.

**What am I caching?** Three common targets: (1) database query results, (2) computed/aggregated data (like a news feed ranking), (3) full HTTP responses at the edge (this overlaps with [[CDN]]).

Beyond the read/write pattern, I always bring up **eviction policy** (LRU is the default answer, LFU if access patterns are skewed and stable), **TTL** (how long before data auto-expires — balances freshness vs hit rate), and **cache invalidation** (the famously "hard problem" — how do you know when to evict something because the underlying data changed).

## Key points
- Caching's whole job is to reduce [[Latency]] and reduce load on the [[Database Scaling|database]] by serving hot data from memory.
- Three main patterns: [[Cache-Aside]] (most common), [[Write-Through]] (consistency-favoring), [[Write-Back]] (write-latency-favoring).
- Eviction: LRU (default), LFU (skewed access patterns), FIFO (rare, only for strict ordering needs).
- "There are only two hard things in computer science: cache invalidation and naming things" — say this, then actually explain your invalidation strategy (TTL, explicit invalidation on write, versioned keys).
- Where to cache: client-side, CDN/edge, application-layer (Redis/Memcached), database query cache — and you can layer multiple of these.

## Related
- [[Cache-Aside]]
- [[Write-Through]]
- [[Write-Back]]
- [[Latency]]
- [[Distributed Caching]]
- [[URL Shortener]]
