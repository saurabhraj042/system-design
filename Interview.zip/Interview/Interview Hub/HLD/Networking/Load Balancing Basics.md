---
tags: [hld, networking]
difficulty: medium
status: not-started
confidence: 0/5
---
# Load Balancing Basics

A load balancer sits in front of a pool of servers and spreads incoming requests across them, so no single server gets overwhelmed and the whole system can scale [[Horizontal vs Vertical Scaling|horizontally]] by just adding more instances behind it. In an interview, the moment you draw more than one application server box, you should also draw a load balancer in front of it — leaving it out is a common gap interviewers flag.

**Algorithms** — I keep a short mental list and pick based on the workload:
- **Round robin**: requests go to servers in rotation. Simple, fine when all servers and all requests are roughly equal.
- **Least connections**: route to whichever server currently has the fewest active connections. Better than round robin when requests have very different processing times.
- **IP hash**: route based on a hash of the client's IP, so the same client tends to land on the same server — a cheap way to get "sticky sessions" without shared session storage. Tradeoff: uneven load if traffic isn't evenly distributed by IP, and it breaks if a server goes down (client gets remapped).

**Layer 4 vs Layer 7**: L4 balances based on IP/port only (fast, protocol-agnostic — TCP/UDP level); L7 balances based on actual HTTP content (can route `/api/video` to one pool and `/api/chat` to another, can do TLS termination, can do smarter health checks). I default to mentioning L7 (e.g., an ALB or NGINX) for most web-facing designs since content-aware routing is usually what you actually want.

**Health checks** are the other detail worth stating explicitly: the load balancer periodically pings each backend, and pulls unhealthy ones out of rotation automatically — this is a core piece of how you get [[Availability]] without manual intervention.

I also flag the load balancer itself as a potential single point of failure — the fix is running multiple load balancer instances behind a floating/virtual IP or using a managed, already-redundant LB (ALB, Cloud Load Balancer) so you're not reinventing that wheel.

## Key points
- Purpose: distribute traffic across multiple servers, enabling [[Horizontal vs Vertical Scaling|horizontal scaling]] and improving [[Availability]].
- Algorithms: round robin (simple/even), least connections (uneven request cost), IP hash (sticky sessions without shared state).
- L4 (IP/port, fast) vs L7 (HTTP-aware, content-based routing, TLS termination) — default to L7 for most web APIs.
- Health checks pull unhealthy backends out of rotation automatically.
- The load balancer itself needs redundancy — don't let it become the single point of failure.

## Related
- [[Horizontal vs Vertical Scaling]]
- [[Availability]]
- [[Rate Limiter]]
- [[Consistent Hashing]]
