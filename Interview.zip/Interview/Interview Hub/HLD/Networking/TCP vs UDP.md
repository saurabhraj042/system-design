---
tags: [hld, networking]
difficulty: easy
status: not-started
confidence: 0/5
---
# TCP vs UDP

TCP and UDP are the two transport-layer protocols almost everything is built on, and the choice between them is really a choice about whether you need reliability guarantees badly enough to pay for them in latency and overhead.

**TCP** is connection-oriented: it does a handshake (SYN, SYN-ACK, ACK) before any data flows, guarantees ordered delivery, retransmits lost packets, and does congestion control. That reliability isn't free — the handshake adds a round trip before you send anything, and retransmission means a single lost packet can hold up everything behind it ("head-of-line blocking"). This is the right choice whenever correctness matters more than raw speed: HTTP/HTTPS APIs, file transfer, anything where a dropped or reordered byte is a real bug.

**UDP** is connectionless and fire-and-forget: no handshake, no ordering guarantee, no retransmission. Whatever you send might arrive, might arrive out of order, might not arrive at all — and the application has to handle that if it cares. This sounds worse, but for the right workload it's exactly right: video/audio calls, live streaming, multiplayer game state, DNS lookups. In these cases, a dropped packet is better handled by "just use the next update" than by "stall everything waiting for a retransmit" — a half-second-old frame you retransmitted is worse than just dropping it and rendering the next one.

In an interview, this comes up most often when designing something with real-time media (a video call feature, live location tracking) — I explicitly say "I'd use UDP here, or more specifically something built on it like WebRTC/RTP, because losing a frame is fine but stalling isn't" — that's a much stronger answer than just picking TCP by default because it's "more reliable."

## Key points
- **TCP**: connection-oriented, ordered, reliable (retransmits), congestion control — costs a handshake + potential head-of-line blocking. Use for correctness-sensitive traffic (APIs, file transfer).
- **UDP**: connectionless, no ordering/reliability guarantees, minimal overhead — no handshake, no retransmission stalls. Use for latency-sensitive, loss-tolerant traffic (video/voice calls, live streaming, gaming, DNS).
- Real-time media systems are usually built on UDP (e.g., WebRTC uses UDP under the hood) — namedrop this for chat/video design questions.
- Don't default to TCP just because it "sounds safer" — justify the choice against the actual data being sent.

## Related
- [[HTTP vs HTTPS]]
- [[Chat Application]]
- [[Latency]]
