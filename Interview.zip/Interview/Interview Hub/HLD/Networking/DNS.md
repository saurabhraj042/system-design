---
tags: [hld, networking]
difficulty: easy
status: not-started
confidence: 0/5
---
# DNS

DNS is the system that turns a human-readable domain name (`api.example.com`) into an IP address a client can actually connect to. In a system design interview it rarely needs deep explanation, but it's worth being fluent in because it's the very first hop in almost every request flow diagram you'll draw, and it quietly does more than just "name → IP."

The lookup itself is a chain: browser/OS cache → ISP resolver → root nameserver → TLD nameserver (`.com`) → authoritative nameserver for the domain, which finally returns the IP. In practice, caching at every layer (with a TTL you control on your DNS records) means most lookups never go past the resolver cache — which is exactly why DNS TTL is a lever you can pull deliberately.

Where DNS actually becomes a *design* decision, not just plumbing: **DNS-based load balancing / geo-routing**. If `api.example.com` resolves to a different IP depending on the requester's location (using something like Route 53 latency-based or geolocation routing), you've effectively built a coarse global load balancer using DNS itself — routing European users to a European data center before a single [[Load Balancing Basics|load balancer]] is even involved. I bring this up when a design needs multi-region support, because it's the first routing decision, before anything inside a region.

The other practical point: lowering your DNS TTL before a planned failover (so clients pick up the new IP fast) vs. the tradeoff of a low TTL meaning more DNS query volume — worth a sentence if the interviewer probes on failover speed.

## Key points
- Resolution chain: cache → resolver → root → TLD → authoritative nameserver → IP, with caching (TTL) at every layer.
- **DNS-based routing/geo-routing** is a real architectural lever for multi-region systems — first line of defense before your load balancer.
- Low TTL = faster failover but more DNS query load; high TTL = fewer queries but slower propagation of changes.
- It's the first hop in your request flow diagram — mention it briefly, don't over-invest interview time here unless multi-region is the actual topic.

## Related
- [[Load Balancing Basics]]
- [[CDN]]
- [[HTTP vs HTTPS]]
