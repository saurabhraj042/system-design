---
tags: [hld, networking]
difficulty: easy
status: not-started
confidence: 0/5
---
# HTTP vs HTTPS

HTTP is the request/response protocol almost every API and web page is built on; HTTPS is HTTP running over TLS, which adds encryption, integrity, and authentication of the server you're talking to. In interviews this rarely needs deep cryptography — the point is to show you know *why* HTTPS is the default assumption for any real system, not to prove you can explain the TLS handshake byte by byte.

The one-liner I use: HTTPS protects against two things — someone eavesdropping on the data in transit (encryption), and someone impersonating your server with a fake one (the certificate, verified by a trusted CA, proves you're actually talking to who you think you are). Without it, anyone on the network path (a coffee shop wifi, an ISP, a malicious router) can read or tamter with the traffic.

Where this becomes an actual design point rather than trivia: **TLS termination**. In a real architecture, TLS is usually terminated at the load balancer or CDN edge (decrypted there), and traffic between the load balancer and internal services often runs as plain HTTP inside a trusted private network — this is a legitimate performance optimization (avoids re-encrypting at every hop) and worth mentioning if asked about the request flow in detail. I'll also bring up **HTTP/2** briefly if performance comes up — multiplexed requests over a single connection, header compression — as the reason a modern API gateway benefits from it over HTTP/1.1's per-connection request queuing.

## Key points
- HTTPS = HTTP + TLS: adds encryption (confidentiality), integrity (tampering detection), and server authentication (via CA-signed certificates).
- Always the default assumption for real systems — say "obviously HTTPS" and move on unless the interviewer specifically wants the handshake details.
- **TLS termination** commonly happens at the load balancer/CDN edge; internal service-to-service traffic inside a private network is often plain HTTP for performance — a good detail to mention when drawing request flow.
- HTTP/2 (multiplexing, header compression) is worth a one-line mention if latency/throughput of an API gateway comes up.

## Related
- [[DNS]]
- [[Load Balancing Basics]]
- [[CDN]]
