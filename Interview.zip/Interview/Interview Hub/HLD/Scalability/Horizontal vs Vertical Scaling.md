---
tags: [hld, scalability]
difficulty: easy
status: not-started
confidence: 0/5
---
# Horizontal vs Vertical Scaling

Vertical scaling ("scale up") means making a single machine bigger — more CPU, more RAM, faster disk. Horizontal scaling ("scale out") means adding more machines and spreading the load across them. Every capacity conversation in a system design interview eventually comes back to this choice, and the honest answer is usually "vertical first, then horizontal once vertical hits a wall."

**Vertical scaling** is simple — no architectural changes, no distributed systems complexity, no need for a [[Load Balancing Basics|load balancer]] or data partitioning. The problem is it has a hard ceiling (there's a biggest machine you can buy) and a single point of failure (that one box goes down, you're down). I use it as the answer for "how do we handle the database being slow" in the early stages of a design, before jumping to sharding.

**Horizontal scaling** removes the ceiling — in theory you can keep adding machines indefinitely — and gives you fault tolerance for free (one instance dies, the others keep serving). The cost is real complexity: you need a [[Load Balancing Basics|load balancer]] to spread traffic, and if the machines need to share state (not just stateless compute), you now have a distributed data problem — this is exactly why [[Database Sharding]] and [[Distributed Caching]] exist, they're horizontal scaling applied to data instead of just compute.

The practical distinction I always draw in an interview: **stateless services** (application/API servers) horizontally scale almost for free — just add more identical instances behind a load balancer, nothing to coordinate. **Stateful services** (databases, caches) horizontally scale with real difficulty — now you need partitioning, replication, and consistency decisions. This is why "just add more servers" is a complete answer for your API layer and a completely different, much harder conversation for your database layer.

## Key points
- Vertical = bigger machine, simple, hard ceiling, single point of failure. Horizontal = more machines, complex, near-unlimited ceiling, built-in fault tolerance.
- Stateless components (API/app servers) scale horizontally almost trivially — just add instances behind a [[Load Balancing Basics|load balancer]].
- Stateful components (databases, caches) scaling horizontally requires real work — partitioning/[[Database Sharding|sharding]], [[Database Replication|replication]], consistency tradeoffs.
- Practical default: scale vertically first (simple, cheap in engineering time), scale horizontally once you hit the ceiling or need fault tolerance.
- Horizontal scaling of compute vs horizontal scaling of data are very different conversations — don't conflate them.

## Related
- [[Load Balancing Basics]]
- [[Database Sharding]]
- [[Distributed Caching]]
- [[Throughput]]
