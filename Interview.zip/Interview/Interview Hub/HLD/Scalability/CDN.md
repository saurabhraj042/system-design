---
tags: [hld, scalability]
difficulty: easy
status: not-started
confidence: 0/5
---
# CDN

A CDN (content delivery network) is a globally distributed set of edge servers that cache and serve content physically close to the user, so requests don't have to travel all the way back to your origin server every time. It's really just caching applied at the network-geography layer — the same mental model as [[Caching Strategies]], but the "distance" being cut is speed-of-light network latency, not compute time.

The clearest case is **static assets**: images, video, JS/CSS bundles, anything that doesn't change per-user. Put these behind a CDN and a user in Mumbai gets served from an edge node in Mumbai instead of a round trip to a server in Virginia — that's a direct, large [[Latency]] win, and it also takes a huge amount of load off your origin servers since the CDN absorbs most of the traffic for that content.

Where it gets more interesting for a system design interview: CDNs aren't just for static files anymore. **Edge caching of API responses** (cache a public, non-personalized API response at the edge with a short TTL) and even **edge compute** (running small pieces of logic at the edge, like Cloudflare Workers) are legitimate design choices worth mentioning if the workload is read-heavy and mostly non-personalized — think a public product catalog or a news feed's non-personalized ranking.

The tradeoff to name explicitly: CDN caching only works well for content that's the same for many users, or at least cacheable per some reasonable key. Highly personalized content (a user's private dashboard) doesn't benefit — you'd cache once per user, which defeats a lot of the purpose, though it can still help with static shells/assets around personalized data.

## Key points
- CDN = distributed edge caching, cutting network distance rather than compute time — same idea as [[Caching Strategies]], different layer.
- Best fit: static assets (images, video, JS/CSS) and non-personalized, cacheable API responses.
- Direct wins: lower [[Latency]] for users far from origin, and massive load reduction on origin servers.
- Modern CDNs also do edge compute (e.g., Cloudflare Workers) — worth a mention for read-heavy, non-personalized workloads.
- Doesn't help much for highly personalized content — name this limitation rather than over-claiming CDN benefits.

## Related
- [[Caching Strategies]]
- [[Latency]]
- [[DNS]]
