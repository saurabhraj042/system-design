---
tags: [hld, scalability]
difficulty: medium
status: not-started
confidence: 0/5
---
# Rate Limiting

Rate limiting caps how many requests a client (a user, an API key, an IP) can make in a given time window, protecting your system from being overwhelmed — whether that's an accidental retry storm, a buggy client, or an actual abusive/malicious user. It's a small feature that gets asked as a full system design question on its own (see [[Rate Limiter]] for the full worked example) because the algorithm choice has real, testable tradeoffs.

**The algorithms**, which is what interviewers actually want you to compare:
- **Fixed window**: count requests in fixed time buckets (e.g., "100 requests per minute, reset at :00"). Simple, but has a burst problem at window boundaries — a client can send 100 requests at 11:59:59 and another 100 at 12:00:00, getting 200 requests in 2 seconds.
- **Sliding window log**: keep a timestamp of every request, count how many fall in the last N seconds on every check. Accurate, no boundary burst problem, but memory-expensive at scale (storing every timestamp per client).
- **Sliding window counter**: approximates the sliding log using weighted counts from the current and previous fixed window — good accuracy, much less memory than the log approach. This is usually my actual answer when asked to pick one — it's the practical middle ground.
- **Token bucket**: a bucket holds tokens, refilled at a fixed rate; each request consumes a token, requests are rejected when the bucket's empty. Naturally allows short bursts (up to the bucket size) while enforcing a steady average rate — this is the one I reach for when the requirement is "allow bursts, but cap the average," which is genuinely the most common real-world requirement.
- **Leaky bucket**: requests queue up and are processed at a fixed rate, like water leaking from a bucket at a constant rate regardless of how fast it's filled. Smooths out bursts into a constant output rate — good when the downstream system truly can't handle any burst at all.

**Where to enforce it and how to distribute state**: for a single server, an in-memory counter is fine. For multiple servers behind a [[Load Balancing Basics|load balancer]], the counter needs to be shared — this is a textbook use of [[Distributed Caching|Redis]] as a fast, shared counter store, and it's the detail that shows you're thinking about the multi-instance reality, not a toy single-box version.

**What to key the limit on** matters too: per-user (fairness across users), per-IP (blunt, but useful against unauthenticated abuse), or per-API-key (typical for a public API with tiers). I always ask "who exactly am I rate limiting, and what happens when they're over the limit" (HTTP 429, with a `Retry-After` header is the standard, polite answer) before diving into the algorithm.

## Key points
- Algorithms: fixed window (simple, boundary burst issue), sliding window log (accurate, memory-heavy), sliding window counter (good practical default), token bucket (allows controlled bursts), leaky bucket (smooths to constant rate).
- Token bucket is usually the right default when "allow some burst but cap the average" is the actual requirement.
- Multi-server deployments need a shared counter store — Redis is the standard answer, ties directly to [[Distributed Caching]].
- Key the limit on the right dimension: per-user, per-IP, or per-API-key, and decide the behavior on breach (HTTP 429 + `Retry-After`).
- Full worked example: [[Rate Limiter]].

## Related
- [[Rate Limiter]]
- [[Distributed Caching]]
- [[Load Balancing Basics]]
- [[Throughput]]
