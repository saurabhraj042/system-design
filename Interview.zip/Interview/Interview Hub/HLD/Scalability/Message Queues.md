---
tags: [hld, scalability]
difficulty: medium
status: not-started
confidence: 0/5
---
# Message Queues

A message queue decouples a producer (something that generates work) from a consumer (something that processes it), letting them run at different speeds without the producer blocking on the consumer. This is one of my go-to answers whenever a system design has a slow or unreliable downstream step — instead of making the user's request wait on it synchronously, drop a message on a queue and process it asynchronously.

The concrete case I use to explain this: a user uploads a video. Transcoding it into multiple resolutions can take minutes. If the API call waits synchronously for transcoding to finish, the user stares at a spinner for minutes and any transcoding hiccup fails the whole request. Instead: the API writes the upload, drops a "transcode this video" message on a queue, and responds immediately. A pool of worker consumers pulls from the queue and does the transcoding at their own pace. This also gives you a natural way to handle load spikes — the queue absorbs a burst of uploads, and workers drain it steadily instead of the system falling over trying to transcode everything at once.

**Point-to-point vs pub/sub**: a traditional queue (SQS, RabbitMQ) delivers each message to exactly one consumer — good for distributing work across a worker pool. Pub/sub (Kafka, SNS) delivers each message to every subscriber — good for fan-out, where multiple independent systems all need to react to the same event (e.g., "order placed" triggers inventory update, email notification, and analytics, all independently).

**Reliability details worth knowing:**
- **At-least-once vs exactly-once delivery**: most queues guarantee at-least-once (a message might be delivered twice if a consumer crashes mid-processing before acknowledging) — so consumers should be **idempotent** (processing the same message twice has the same effect as once). This is the detail that separates a real answer from a hand-wavy one.
- **Dead-letter queues**: messages that repeatedly fail processing get moved to a separate queue instead of blocking/retrying forever — lets you inspect and fix failures without losing them.
- **Backpressure**: if consumers can't keep up, the queue grows — you either need to scale consumers, or the queue needs a way to signal producers to slow down.

## Key points
- Decouples producer from consumer — enables async processing, absorbs load spikes, isolates slow/flaky downstream work from the user-facing request path.
- Point-to-point (one consumer per message, work distribution) vs pub/sub (every subscriber gets it, event fan-out) — pick based on whether it's "do this work" or "notify everyone this happened."
- Most queues are at-least-once delivery → consumers must be idempotent, always mention this.
- Dead-letter queues handle repeatedly-failing messages without losing them or blocking the queue.
- Real tools to namedrop: SQS/RabbitMQ (point-to-point), Kafka/SNS (pub/sub, and Kafka specifically for high-throughput event streaming with replay).

## Related
- [[Throughput]]
- [[Rate Limiter]]
- [[Chat Application]]
