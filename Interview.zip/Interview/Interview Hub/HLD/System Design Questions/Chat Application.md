---
tags: [hld, system-design-questions]
difficulty: hard
status: not-started
confidence: 0/5
---
# Chat Application

This is the question where "just add a cache" isn't the answer anymore — the core challenge is real-time bidirectional communication and message ordering, which pulls in almost everything else in this vault. I treat this as the capstone question — if I can talk through this cleanly, the rest feel easier by comparison.

## Requirements
- Functional: 1:1 and group messaging, message delivery (ideally with delivery/read receipts), online/offline presence, message history.
- Non-functional: low latency for message delivery (this is the whole point of a chat app), messages must arrive in the correct order within a conversation, high availability, and it needs to scale to many concurrent connections, not just many requests/sec — this last point is the key thing that makes chat different from a typical CRUD system design question.

## The core architectural decision: how does the server push messages to a client?
HTTP request/response doesn't work for "push a message to a client the instant it arrives" — the server has no way to initiate contact with a client that isn't currently asking. Options:
- **Polling**: client asks "any new messages?" every few seconds. Simple, but wastes requests and adds latency up to the poll interval.
- **Long polling**: client asks and the server holds the connection open until there's a message (or a timeout). Better latency than polling, but still re-establishes a connection per cycle.
- **WebSockets**: a single persistent, full-duplex connection between client and server — the server can push a message the instant it arrives, no polling at all. This is the standard real answer for chat, and I'd justify it directly: chat needs low-latency, frequent, bidirectional small messages, which is exactly what WebSockets (built on [[TCP vs UDP|TCP]], not UDP, because message loss/reordering would be a real bug here) are designed for.

## High-level flow
1. Client A opens a persistent WebSocket connection to a **chat server** (one of many, behind a connection-aware load balancer — WebSocket connections are stateful, so this isn't quite the same as [[Load Balancing Basics|stateless round-robin balancing]]; you need the same client to stay on the same server for the life of the connection, or a way to route messages between servers).
2. Client A sends a message for a conversation with Client B.
3. The chat server checks: is Client B connected to *this same* server? If yes, push directly. If no — and this is the interesting distributed systems bit — the server needs to find which server Client B is connected to and forward the message there.
4. **This lookup is a presence/routing problem**: a fast shared store (Redis) mapping `user_id → server_id` for currently-connected users. This is another concrete case of [[Distributed Caching]] — a shared, fast key-value lookup that every chat server can query.
5. If Client B is offline entirely, the message is persisted and delivered on next connect (push notification can also be triggered here for mobile).

## Data model and storage
Messages need to be stored for history, and the access pattern is very specific: "give me the last N messages in conversation X, in order." This points toward [[Database Sharding|sharding by `conversation_id`]] — it keeps the single most common query (message history for one conversation) entirely within one shard, avoiding the cross-shard query problem that sharding usually introduces. A wide-column store (see [[SQL vs NoSQL]]) is a genuinely good fit here — messages are append-heavy, queried by conversation + time range, which is exactly what wide-column stores like Cassandra are built for.

## Message ordering and delivery guarantees
Within a single conversation, ordering matters (you don't want message 2 rendering before message 1). A per-conversation sequence number (or relying on the shard/partition to naturally serialize writes for that conversation) keeps this simple — this is a case where I'd explicitly want **strong-ish consistency per conversation** even though the system as a whole leans toward availability, tying directly back to [[Consistency]] and [[CAP Theorem]] — not every piece of data in the same system needs the same consistency model.

## Where the rest of the vault plugs in
- **Presence** ("user is online") is a perfect [[Write-Back|write-back]] caching case — extremely high write volume, loss-tolerant (missing one status flicker doesn't matter), no need to hit durable storage synchronously.
- **Fan-out for group chats**: sending one message to a 500-person group is a fan-out problem, similar in spirit to [[Message Queues|pub/sub message queues]] — publish once, deliver to many subscribed connections.
- **Scaling the WebSocket layer itself** is a [[Horizontal vs Vertical Scaling|horizontal scaling]] problem for stateful connections — more chat servers, with the Redis presence lookup as the glue tying them together.
- **Typing indicators** are the textbook example of data that's fine to be wildly eventually consistent — worth explicitly contrasting against message delivery, which isn't, to show you're applying [[Consistency]] per data type rather than uniformly.

## Related
- [[TCP vs UDP]]
- [[Distributed Caching]]
- [[Database Sharding]]
- [[SQL vs NoSQL]]
- [[Consistency]]
- [[CAP Theorem]]
- [[Write-Back]]
- [[Message Queues]]
- [[Horizontal vs Vertical Scaling]]
