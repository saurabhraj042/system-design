---
tags: [hld, system-design-questions]
difficulty: medium
status: not-started
confidence: 0/5
---
# Rate Limiter

This question is deceptively small — one API, basically one decision (allow/deny) — but interviewers use it to test whether you actually understand algorithm tradeoffs and distributed state, not whether you can draw a big architecture diagram. Depth beats breadth here.

## Requirements
- Functional: limit each client to N requests per time window; reject requests over the limit with a clear signal.
- Non-functional: the rate limiter itself must be fast (it sits in front of every request, so it can't become the new bottleneck) and must work correctly across multiple application server instances, not just one.
- Clarify with the interviewer: rate limit per user? per IP? per API key? Global or per-endpoint? I always ask this before designing anything, since it changes the key I'm counting against.

## The core decision: which algorithm
This is the heart of the answer — see [[Rate Limiting]] for the full comparison, but here's how I'd actually present it in an interview:

"I'd default to **token bucket**: each client gets a bucket of tokens that refills at a steady rate, and each request consumes one token. This naturally allows a client to burst up to the bucket size while still capping their long-run average rate — which matches how real clients actually behave (a user might fire 5 requests in a row loading a page, then go quiet)."

I'd contrast it with **fixed window** (simpler to implement, but has the boundary-burst flaw — a client can get 2x the limit by timing requests around the window edge) and **sliding window counter** (a good practical alternative to token bucket if the interviewer wants tighter guarantees against the boundary problem, at slightly more implementation complexity than fixed window).

## Where state lives — this is the actual system design part
A single-server, in-memory counter is trivial and not what's being tested. The real question: you have multiple app servers behind a [[Load Balancing Basics|load balancer]], and a client's requests might land on any of them. If each server tracks its own counter independently, a client could get N requests per server — N × (number of servers) total, way over the intended limit.

**Fix: centralize the counter in a shared, fast store — Redis.** Each request does an atomic increment-and-check against a Redis key like `rate_limit:{user_id}:{window}`, with a TTL matching the window so old keys clean up automatically. Redis's single-threaded atomic operations (`INCR`, or a Lua script for token bucket logic) make this safe under concurrent access without extra locking. This is a direct application of [[Distributed Caching]] — a rate limiter is really just "a distributed, fast, shared counter."

## Handling the Redis dependency itself
Two follow-up questions I proactively address, because interviewers always probe here:
- **What if Redis is slow or down?** Fail open (allow the request) or fail closed (reject it) — I'd argue for fail-open for most APIs, since a rate limiter being briefly unavailable shouldn't take down the whole product; the alternative (fail-closed) turns a caching-layer hiccup into a full outage.
- **What if Redis itself needs to scale?** At very high request volume, even Redis can become a bottleneck — this is where [[Consistent Hashing]] comes back in, sharding the rate-limit keys across multiple Redis nodes so no single node is checking every request.

## API-level behavior
On rejection: HTTP `429 Too Many Requests`, with a `Retry-After` header telling the client when they can try again — small detail, but it's the kind of "I've actually built this" signal that's easy to include and easy to forget.

## Where to enforce it
Worth a one-line mention: rate limiting is often enforced at the **API gateway / [[Load Balancing Basics|load balancer]] layer** (before requests even reach application servers) rather than inside each service — cheaper, more consistent, and protects backend services uniformly.

## Related
- [[Rate Limiting]]
- [[Distributed Caching]]
- [[Consistent Hashing]]
- [[Load Balancing Basics]]
- [[Throughput]]
