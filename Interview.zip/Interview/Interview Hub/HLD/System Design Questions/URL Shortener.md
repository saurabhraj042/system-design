---
tags: [hld, system-design-questions]
difficulty: easy
status: not-started
confidence: 0/5
---
# URL Shortener

This is the "hello world" of system design interviews — it's popular precisely because it's small enough to fully finish in 45 minutes but touches almost every fundamental concept, so it's a great one to have fully internalized as a template for how you structure *any* answer.

## Requirements (say these out loud first)
- Functional: given a long URL, generate a short one; given a short URL, redirect to the original long URL.
- Non-functional: low latency on redirect (this is the hot path, gets hit constantly), high availability, URLs should be unguessable-ish (not sequential/predictable), read-heavy (redirects massively outnumber creations — realistically 100:1 or more).

## Capacity estimate (do this early, it drives every decision after)
Say we want to support 100M new URLs/month and a 100:1 read:write ratio.
- Writes: 100M / month ≈ ~40 URLs/sec average (spiky, so design for peak, maybe 5-10x that).
- Reads: 100:1 ratio → ~4,000 redirects/sec average. This single number is why caching isn't optional here — see [[Throughput]] for how this estimate turns into "how many servers/cache nodes do I need."
- Storage: 100M URLs/month × 500 bytes/record × 12 months × 5 years ≈ a few TB over 5 years — not huge, a single well-indexed table handles this for a long time before [[Database Sharding|sharding]] is even a real conversation.

## API design
- `POST /api/shorten { long_url }` → `{ short_url }`
- `GET /{short_code}` → HTTP 301/302 redirect to the long URL

## Core design: generating the short code
Two real approaches, and I explain both because the tradeoff is the actual interesting part:
1. **Base62 encode an auto-incrementing ID.** A counter (from the DB or a dedicated ID-generation service) gives a unique integer, encode it in base62 (a-z, A-Z, 0-9) to get a short, dense code. Simple, guaranteed-unique, but sequential IDs are somewhat predictable/guessable, and a single counter can become a bottleneck at very high write throughput (mitigated with pre-allocated ID ranges per server).
2. **Hash the long URL (e.g., MD5) and take the first 7 characters.** No central counter needed, but collisions are possible (two different URLs producing the same short prefix) — you have to check for and handle collisions (append a character, rehash), which adds complexity back in.
I'd default to base62-encoded counter with range allocation per app server — it avoids the collision-handling complexity and scales the write path cleanly.

## Data model
`short_code (PK) | long_url | created_at | expires_at | user_id (optional)`
Simple key-value shape — this is actually a strong argument for a **key-value NoSQL store** (or a relational table with just an index on the primary key) over something with complex relationships. See [[SQL vs NoSQL]] for the general framework — here, the data literally has no relationships to join across, which points toward key-value.

## The redirect path — where caching does the real work
Redirects are the hot path (remember, ~4,000/sec), and short URLs follow a power law — a small number of links get the vast majority of clicks. This is close to a textbook case for [[Cache-Aside]]: check a cache (Redis) for the short code first, only hit the database on a miss. Because this is a pure lookup with no complex invalidation need (a short URL's target basically never changes once created), cache-aside with a long TTL is close to ideal here — much simpler than justifying [[Write-Through]] for data that's effectively immutable.

## Scaling the whole thing
- **[[Load Balancing Basics|Load balancer]]** in front of stateless app servers — trivial horizontal scaling for the API layer itself, see [[Horizontal vs Vertical Scaling]].
- **[[Caching Strategies|Cache]]** absorbs almost all redirect traffic, as above.
- **[[CDN]]** is arguably overkill here since this isn't static content, but geo-distributed caching layers (regional Redis) achieve the same latency win for a global user base.
- **[[Database Scaling]] order**: at 100M/month this table is indexable and small enough that indexing + caching alone likely carries you for years — I'd explicitly say I would *not* shard this yet, and explain why, since knowing when *not* to add complexity is as important as knowing the technique.

## Related
- [[Caching Strategies]]
- [[Cache-Aside]]
- [[SQL vs NoSQL]]
- [[Database Scaling]]
- [[Load Balancing Basics]]
- [[Throughput]]
