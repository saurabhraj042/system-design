---
tags: [hld, fundamentals]
difficulty: easy
status: not-started
confidence: 0/5
---
# Availability

Availability is the percentage of time a system is up and successfully serving requests. It's usually expressed in "nines" — 99.9% ("three nines") means about 8.7 hours of downtime a year; 99.99% ("four nines") means about 52 minutes a year. Interviewers love asking you to justify a number here because it forces you to make real tradeoffs instead of just saying "make it highly available" and moving on.

The way I actually use this in an interview: availability is bought with redundancy, and redundancy costs money and adds consistency headaches. So the moment I commit to a target (say 99.99%), I immediately think about what that implies — multiple availability zones, no single point of failure, replicas for the database, health checks + auto-failover for the load balancer. If I don't connect the number to concrete architecture decisions, I haven't really answered the question.

The other half of this conversation is always [[CAP Theorem]] — in a network partition, you have to choose between staying available (serving possibly-stale data) or staying consistent (rejecting requests until you're sure). Most real systems (social feeds, e-commerce catalogs) pick availability; systems handling money or inventory often lean consistency for the critical path.

## Key points
- **Nines math**: 99.9% ≈ 8.7 hrs/year down, 99.99% ≈ 52 min/year down, 99.999% ≈ 5 min/year down — memorize this, it comes up constantly.
- **How you actually get availability**: redundancy (multiple instances, multiple AZs/regions), no single point of failure, health checks with automatic failover, graceful degradation instead of hard failure.
- **Availability is a spectrum, not a boolean**: you can degrade gracefully (serve cached/stale data, disable non-critical features) instead of going fully down.
- **SLA vs SLO vs SLI**: SLI is the measured metric, SLO is your internal target, SLA is the external promise (often with financial penalties) — good to namedrop, shows you've worked with this in production.

## Related
- [[CAP Theorem]]
- [[Database Replication]]
- [[Consistency]]
- [[Load Balancing Basics]]
