---
tags: [hld, fundamentals]
difficulty: easy
status: not-started
confidence: 0/5
---
# Throughput

Throughput is how many requests (or bytes, or transactions) a system can process per unit time. Where latency is about one request's experience, throughput is about the system's overall capacity — it's the number you quote when someone asks "how many users can this handle?"

In an interview, I use throughput as the anchor for capacity estimation. Once I know the required throughput (say, 10K requests/sec), I can back-calculate how many servers I need, how much a single database instance can handle before I need to shard, and whether a single message queue partition is enough. This is usually the very first math I do in a system design interview, right after clarifying requirements.

The important nuance: throughput and latency aren't independent. Pushing throughput too high (overloading a server) causes queueing, which spikes latency. That's the whole reason horizontal scaling and load balancing exist — to keep throughput high while keeping per-request latency low by spreading load instead of queueing it on one box.

## Key points
- **Capacity estimation**: throughput requirement → number of servers needed → informs whether you need horizontal scaling at all.
- **Little's Law**: `concurrency = throughput × latency`. If you know two, you can derive the third — useful for sanity-checking your napkin math live in an interview.
- **Throughput vs latency tradeoff**: batching, queueing, and buffering all increase throughput but add latency for individual items.
- **Where throughput bottlenecks usually live**: single-threaded components, a database with no read replicas, a message queue with too few partitions, a load balancer routing to too few backend instances.

## Related
- [[Latency]]
- [[Horizontal vs Vertical Scaling]]
- [[Message Queues]]
- [[Rate Limiter]]
