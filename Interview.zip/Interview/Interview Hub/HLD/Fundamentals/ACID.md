---
tags: [hld, fundamentals]
difficulty: medium
status: not-started
confidence: 0/5
---
# ACID

ACID is the set of guarantees a transactional database gives you so you can reason about correctness without thinking about concurrency or crashes yourself. It comes up in interviews the moment money, inventory, or bookings enter the picture — anywhere a "lost update" or "double-booked seat" would be a real bug, not just a UX annoyance.

I explain it as four separate promises:
- **Atomicity**: a transaction either fully happens or fully doesn't — no half-applied transfers where money leaves one account but never arrives in the other.
- **Consistency** (the database kind, not the CAP kind — these names collide and it trips people up): the database moves from one valid state to another, respecting constraints, foreign keys, etc.
- **Isolation**: concurrent transactions don't see each other's half-finished work. This is the one with actual depth — isolation levels (read committed, repeatable read, serializable) trade correctness for throughput, and knowing this distinguishes a strong answer from a shallow one.
- **Durability**: once committed, a write survives a crash — it's on disk, not just in memory.

In a system design interview, ACID is my signal for "this needs a relational database, not a NoSQL store" — e.g., a payments ledger or a seat-booking system. I'll usually say something like "I want ACID transactions here because two users racing to book the last seat is a correctness problem, not just a performance one," which ties the theory directly to the design decision.

## Key points
- **A**tomicity, **C**onsistency, **I**solation, **D**urability — but say what each means, don't just recite the acronym.
- **"Consistency" in ACID ≠ "Consistency" in CAP** — ACID's C is about valid data/constraints, CAP's C is about replicas agreeing. Call this out explicitly if it comes up, it shows precision.
- **Isolation levels are a spectrum** (read uncommitted → read committed → repeatable read → serializable) — stronger isolation = more correctness, less concurrency/throughput.
- **When to reach for ACID**: money movement, inventory/booking systems, anything where a race condition causes real-world harm, not just a stale UI.
- **NoSQL tradeoff**: most NoSQL stores relax ACID (especially isolation and multi-row atomicity) in exchange for horizontal scalability — this is the crux of the [[SQL vs NoSQL]] decision.

## Related
- [[CAP Theorem]]
- [[Consistency]]
- [[SQL vs NoSQL]]
- [[Database Replication]]
