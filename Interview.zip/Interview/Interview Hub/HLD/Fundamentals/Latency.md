---
tags: [hld, fundamentals]
difficulty: easy
status: not-started
confidence: 0/5
---
# Latency

Latency is how long a single request takes from the moment it's sent to the moment the response comes back. In an interview, this is the number you're implicitly optimizing every time you say "let's add a cache" or "let's use a CDN" — you're really saying "let's cut latency for the common path."

The trap people fall into is talking about latency and throughput as if they're the same thing. They're not. A system can have terrible latency (each request takes 2 seconds) but great throughput (it handles 50,000 requests/sec because it's massively parallel). Know which one you're solving for before you propose a fix.

When I'm asked "how would you make this faster," I mentally split it into: where is the time being spent (network hop, disk I/O, compute, lock contention), and is this on the critical path for the user or can it happen async. That's usually enough to steer the conversation toward caching, indexing, or async processing.

## Key points
- **p50/p90/p99**: always ask "latency for whom?" — p99 tells you about your worst-off users, and it's usually what interviewers actually care about, not average latency.
- **Tail latency amplification**: if one request fans out to 10 backend calls, your overall p99 is dominated by the slowest of those 10 — this is why fan-out heavy architectures need aggressive timeouts.
- **Common levers to reduce latency**: caching (avoid re-computation), CDN (avoid network distance), indexing (avoid full scans), async processing (move work off the critical path), connection pooling (avoid handshake overhead).
- **Latency vs throughput**: latency = time per request, throughput = requests per second. You can trade one for the other (e.g., batching improves throughput but can hurt latency for individual items).

## Related
- [[Throughput]]
- [[CDN]]
- [[Caching Strategies]]
- [[CAP Theorem]]
