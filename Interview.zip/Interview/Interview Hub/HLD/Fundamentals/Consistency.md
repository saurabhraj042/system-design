---
tags: [hld, fundamentals]
difficulty: medium
status: not-started
confidence: 0/5
---
# Consistency

Consistency means every reader sees the same data at the same time — no stale reads, no "I just wrote this but the API is showing me the old value." In distributed systems this is genuinely hard because data usually lives on multiple replicas, and keeping them all in perfect sync in real time conflicts directly with availability and latency.

In an interview, I treat "consistency" as a spectrum, not a single setting:
- **Strong consistency**: every read gets the latest write, no matter which replica serves it. Expensive — usually means synchronous replication and higher write latency.
- **Eventual consistency**: replicas converge to the same value eventually, but a read right after a write might return stale data. Cheap and fast, and fine for things like "likes count" or "follower count."
- **Read-your-writes consistency**: a middle ground — the user who made the write always sees their own write immediately, even if other users see it with a delay. This is what most social apps actually implement, and it's a great answer to drop when an interviewer pushes on "but what about consistency" for a feed or comments feature.

The real skill being tested here isn't reciting definitions — it's picking the right consistency level for the right piece of data within the same system. A chat app's message ordering probably needs strong consistency per-conversation, but the "user is typing…" indicator can be wildly eventually consistent and nobody cares.

## Key points
- **Strong vs eventual vs read-your-writes** — know all three and have a real example for each.
- **Consistency costs latency and availability** — this is the whole point of [[CAP Theorem]], it's not academic.
- **Different data in the same system can have different consistency needs** — don't apply one consistency model to your whole design, apply it per data type.
- **Replication lag** is the physical reason eventual consistency exists — writes go to a primary, replicas catch up asynchronously.

## Related
- [[CAP Theorem]]
- [[ACID]]
- [[Database Replication]]
- [[Availability]]
