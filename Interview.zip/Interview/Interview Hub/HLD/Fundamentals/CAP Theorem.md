---
tags: [hld, fundamentals]
difficulty: medium
status: not-started
confidence: 0/5
---
# CAP Theorem

CAP says a distributed system can only guarantee two of three properties at the same time: **C**onsistency (every node sees the same data), **A**vailability (every request gets a response), and **P**artition tolerance (the system keeps working even when nodes can't talk to each other). In practice, network partitions *will* happen, so partition tolerance isn't really optional — the real choice interviewers want you to make is **CP vs AP** when a partition occurs.

Here's how I actually frame it out loud in an interview instead of just reciting the theorem: "If the network splits and two nodes can't agree, do I reject the write until they're back in sync (consistent, but now unavailable), or do I accept the write on both sides and reconcile later (available, but now temporarily inconsistent)?" That framing makes it obvious this is a business decision, not a technical one — a banking ledger picks CP, a social media like-counter picks AP.

This is one of those concepts where naming real systems makes you sound like you've actually worked with this: DynamoDB and Cassandra lean AP (tunable consistency), traditional single-primary relational databases and systems like ZooKeeper/etcd lean CP. I always tie CAP back to the specific feature I'm designing rather than leaving it abstract — e.g., "for the message ordering in this chat app I want CP, for the online-status indicator I'm fine with AP."

## Key points
- **P is not optional** in real distributed systems — partitions happen, so the real tradeoff is C vs A during a partition.
- **CP systems**: reject requests during a partition to preserve consistency (e.g., traditional RDBMS with synchronous replication, ZooKeeper/etcd).
- **AP systems**: keep serving requests during a partition, accept temporary inconsistency, reconcile later (e.g., DynamoDB, Cassandra).
- **Tie the choice to the specific feature**, not the whole system — most real designs are CP for some data and AP for other data.
- Related but distinct: **PACELC** extends CAP by also asking "in the absence of a partition, do you trade latency for consistency?" — worth mentioning if you want to show depth.

## Related
- [[Consistency]]
- [[Availability]]
- [[ACID]]
- [[Database Replication]]
