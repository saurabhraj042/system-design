# 🧠 DSA Master Index — SDE-2 Preparation

> **Role:** Senior Staff Engineer + Bar Raiser Mentor
> **Target:** SDE-2 roles across FAANG / Product companies
> **Started:** 2026
> **Philosophy:** Pattern recognition over memorization. Reasoning over recall.

---

## 📁 Vault Structure

```
DSA/
├── DSA Master Index.md          ← You are here
├── Patterns/
│   ├── 00 - Pattern Master Map.md
│   ├── 01 - Sliding Window.md
│   ├── 02 - Two Pointers.md
│   ├── 03 - Binary Search on Answer.md
│   ├── 04 - Prefix Sum & Difference Array.md
│   ├── 05 - HashMap & Frequency Map.md
│   ├── 06 - Monotonic Stack.md
│   ├── 07 - Heap & Priority Queue.md
│   ├── 08 - Tree Traversal Patterns.md
│   ├── 09 - Graph BFS DFS Union-Find.md
│   ├── 10 - Dynamic Programming.md
│   ├── 11 - Backtracking.md
│   ├── 12 - Merge Intervals.md
│   ├── 13 - Trie.md
│   ├── 14 - Graph DP.md
│   ├── 15 - Bit Manipulation.md
│   ├── 16 - Divide and Conquer.md
│   ├── 17 - Greedy.md
│   └── 18 - Design-Based DSA.md
├── Drills/
│   └── Sliding Window — Problem Drill 01.md
└── Interview Intel/
    ├── 2025-2026 Real Interview Experiences.md
    └── LLM-Proof DSA — The 2026 Shift.md
```

---

## 🎯 The SDE-2 Standard

> *"If you can quickly identify the underlying patterns in new problems (dynamic programming, graph traversal, etc.), you're likely ready."*
> — Devang, Amazon SDE (IGotAnOffer, 2025)

You are considered SDE-2 ready when:
- You can solve LC Medium–Hard in **30–45 minutes**
- You identify the **pattern in under 2 minutes**
- You state **Time + Space complexity before coding**
- You proactively raise **edge cases and follow-ups**
- You can explain **two approaches and trade off between them**

---

## 📊 Pattern Tier System

| Tier | Description | Patterns |
|------|-------------|----------|
| 🔴 Tier 1 | High frequency, high signal — must master | Sliding Window, Two Pointers, Binary Search, Prefix Sum, HashMap, Monotonic Stack, Heap |
| 🟠 Tier 2 | Medium frequency, deep knowledge needed | Tree Traversal, Graph BFS/DFS/UF, DP, Backtracking, Merge Intervals, Trie |
| 🟡 Tier 3 | Selective depth, high signal at SDE-2 level | Graph DP, Bit Manipulation, Divide & Conquer, Greedy, Design DS |

---

## 🗓️ 8-Week Prep Protocol

| Week | Focus Area | Daily Target |
|------|------------|--------------|
| 1–2 | Arrays, Strings, HashMaps, Two Pointers | 3 problems/day |
| 3 | Sliding Window, Prefix Sum, Binary Search | 3 problems/day |
| 4 | Stacks (Monotonic), Queues, Heaps | 3 problems/day |
| 5 | Trees (all traversals), BST, Tries | 2–3 problems/day |
| 6 | Graphs (BFS/DFS/Dijkstra/Topo/Union-Find) | 2 problems/day |
| 7 | Dynamic Programming (all 6 archetypes) | 2 problems/day |
| 8 | Backtracking, Greedy, Design DS + Full Mocks | Full mock daily |

**Spaced Repetition Rule:** Use the 3-7-15 rule — solve a problem, revisit after 3 days, then 7, then 15.

---

## 🔑 The 2026 Problem-Solving Framework

```
Step 1: READ    — Understand constraints (N ≤ 10^5 → O(N log N) max)
Step 2: OBSERVE — What property is special? (sorted? distinct? bounded?)
Step 3: PATTERN — Which of the 18 patterns fits this observation?
Step 4: PROVE   — Why is this pattern correct? (greedy? optimal substructure?)
Step 5: CODE    — Write clean, modular code with named functions
Step 6: VERIFY  — Dry run on small input + check edge cases
Step 7: OPTIMIZE— Can space be reduced? One pass instead of two?
```

---

## 🔗 Quick Links

- [[00 - Pattern Master Map]] — Full pattern × company frequency matrix
- [[LLM-Proof DSA — The 2026 Shift]] — What's changing in interviews
- [[2025-2026 Real Interview Experiences]] — Ground truth from real candidates
- [[Sliding Window — Problem Drill 01]] — First drill session
