# 🎯 Drill 01 — Sliding Window: Beginner Session

> **Pattern:** [[01 - Sliding Window|Sliding Window]]
> **Session date:** 2026
> **Level:** Beginner → SDE-2

---

## 📖 Session Summary

This was the first pattern drill. We started from scratch — building intuition before touching code.

---

## 🧠 The Intuition Built

**The Naive Brute Force Brain:**
Given `[2, 1, 5, 1, 3, 2]`, find max sum of 3 consecutive elements.
- Check [2,1,5]=8, [1,5,1]=7, [5,1,3]=9, [1,3,2]=6 → O(N×K)

**The Sliding Window Insight:**
Instead of recomputing the sum from scratch each time, *reuse* the previous sum.
- Next window = Previous window - left element + new right element → O(N)

This is the core of sliding window: **avoid recomputation through incremental update.**

---

## 📝 Problems Covered

### Problem 1 — Longest Substring Without Repeating Characters
**LeetCode:** 3

**Pattern:** Variable-size sliding window

**Key insight:** Store the *index* of last occurrence (not just existence) so you can jump `left` pointer directly instead of sliding one step at a time.

```python
def lengthOfLongestSubstring(s: str) -> int:
    last_seen = {}   # char → last seen index
    left = 0
    result = 0

    for right, char in enumerate(s):
        if char in last_seen and last_seen[char] >= left:
            left = last_seen[char] + 1
        last_seen[char] = right
        result = max(result, right - left + 1)

    return result
```

**Dry Run on `"abcabcbb"`:**
```
right=0: 'a' not in window → window="a", result=1
right=1: 'b' not in window → window="ab", result=2
right=2: 'c' not in window → window="abc", result=3
right=3: 'a' seen at idx 0, left→1 → window="bca", result=3
right=4: 'b' seen at idx 1, left→2 → window="cab", result=3
right=5: 'c' seen at idx 2, left→3 → window="abc", result=3
right=6: 'b' seen at idx 4, left→5 → window="cb", result=3
right=7: 'b' seen at idx 6, left→7 → window="b", result=3
Output: 3
```

**Complexity:** O(N) time, O(min(N, A)) space where A = alphabet size

**Edge cases:**
- Empty string → return 0
- All same chars → return 1
- All unique → return len(s)

---

## 🔥 Bar Raiser Questions from This Session

**Q: What if the array has negative numbers — does sliding window work?**
A: No. Sliding window assumes adding an element can only change sum in one direction. With negatives, shrinking the window might worsen the result. Use Kadane's or prefix sums instead. Always clarify: "Are values guaranteed non-negative?"

**Q: Can you do this in a single pass?**
A: Yes — the two-pointer approach IS a single pass. Both `left` and `right` each traverse the array at most once.

**Q: What's the worst-case number of left-pointer moves?**
A: O(N). Each element is added exactly once (right moves) and removed at most once (left moves). Total = 2N operations.

---

## 📌 Next Steps

- [ ] Solve: Minimum Size Subarray Sum (LC 209)
- [ ] Solve: Longest Substring with At Most K Distinct Characters (LC 340)
- [ ] Solve: Minimum Window Substring (LC 76) — Hard
- [ ] Review the "Exactly K" trick: `atMost(K) - atMost(K-1)`

---

## 🔗 Links

- [[01 - Sliding Window]] — Full pattern notes
- [[DSA Master Index]] — Back to index
