# 🕸️ Pattern 09 — Graph: BFS, DFS & Union-Find

**Tier:** 🟠 Tier 2 — Deep Knowledge Required
**Frequency:** Amazon ⭐⭐⭐⭐⭐ | Google ⭐⭐⭐⭐⭐ | Meta ⭐⭐⭐⭐

---

## 🧠 Core Intuition

**BFS:** Explores level by level → shortest path in unweighted graphs.
**DFS:** Explores depth-first → connected components, cycle detection, topological sort.
**Union-Find:** Efficiently tracks which elements belong to the same component → merge/find in near O(1).

---

## 🔍 When to Use Which

```
Shortest path (unweighted graph)     → BFS
Connected components                 → DFS or Union-Find
Cycle detection (directed)           → DFS with recursion stack
Cycle detection (undirected)         → Union-Find
Topological ordering                 → DFS (finish time) or Kahn's BFS
Merge islands dynamically            → Union-Find
Weighted shortest path               → Dijkstra (priority queue + BFS)
Negative weights                     → Bellman-Ford
```

---

## 📐 Templates

### BFS Template
```python
from collections import deque

def bfs(graph, start):
    visited = set([start])
    queue = deque([start])

    while queue:
        node = queue.popleft()
        process(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
```

### DFS Template (Iterative)
```python
def dfs(graph, start):
    visited = set()
    stack = [start]

    while stack:
        node = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        process(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                stack.append(neighbor)
```

### Union-Find Template (with Path Compression + Union by Rank)
```python
class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
        self.components = n

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # Path compression
        return self.parent[x]

    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        if px == py:
            return False   # Already same component
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1
        self.components -= 1
        return True
```

### Topological Sort — Kahn's Algorithm (BFS)
```python
from collections import deque

def topoSort(n, edges):
    in_degree = [0] * n
    graph = [[] for _ in range(n)]
    for u, v in edges:
        graph[u].append(v)
        in_degree[v] += 1

    queue = deque(i for i in range(n) if in_degree[i] == 0)
    order = []

    while queue:
        node = queue.popleft()
        order.append(node)
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    return order if len(order) == n else []  # Empty = cycle exists
```

---

## 📝 Canonical Problems

| Problem | Approach | Key Insight |
|---------|----------|-------------|
| Number of Islands | DFS/BFS on grid | Flood fill — mark visited as '0' |
| Largest Island (follow-up) | Union-Find | Assign island IDs, check neighbors |
| Course Schedule | Topo Sort | Detect cycle in directed graph |
| Clone Graph | BFS + HashMap | Old node → new node mapping |
| Word Ladder | BFS | Each word = node, differ by 1 letter = edge |
| Dijkstra (shortest weighted path) | Min-heap BFS | Relax edges by priority |
| Pacific Atlantic Water Flow | DFS from both oceans | Reverse flow direction |

---

## 🔥 Real Amazon Interview Question

> *"Compute the size of the largest island in a given matrix. Follow-up: if you can change at most one sea cell (0) to land (1), what's the largest island?"*

**Solution:** 
1. First pass: label each island with a unique ID using DFS, store sizes in a map.
2. Second pass: for each sea cell, check all 4 neighbors, sum up unique island sizes + 1.
3. Return max of all such sums.

Union-Find makes this elegant — assign each land cell to its root, use rank/size tracking.

---

## 📊 Complexity

| Algorithm | Time | Space |
|-----------|------|-------|
| BFS/DFS | O(V + E) | O(V) |
| Union-Find (with optimizations) | O(α(N)) per op ≈ O(1) | O(N) |
| Dijkstra | O((V + E) log V) | O(V) |
| Topological Sort | O(V + E) | O(V) |

---

## 🚨 Edge Cases

```
1. Disconnected graph         → loop over all nodes to start BFS/DFS
2. Self-loops                 → handle in cycle detection
3. Grid with single cell      → check bounds carefully
4. No valid topological order → cycle exists, return []
5. Dijkstra with 0-weight edges → use 0-1 BFS (deque) instead of heap
```
