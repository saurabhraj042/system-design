# 📚 Pattern 06 — Monotonic Stack

**Tier:** 🔴 Tier 1 — Must Master
**Frequency:** Amazon ⭐⭐⭐⭐ | Meta ⭐⭐⭐⭐ | Google ⭐⭐⭐
**2026 trend:** Increasingly used as an "emerging trend" pattern in FAANG rounds

---

## 🧠 Core Intuition

A stack where elements are maintained in **monotonically increasing or decreasing order**.
When a new element violates the invariant, we pop — and at each pop, we've found the answer for that element.

**Mental model:** The stack holds *candidates* that haven't found their answer yet.

---

## 🔍 Pattern Recognition Triggers

- "Next Greater Element" → Monotonic Decreasing Stack
- "Previous Smaller Element" → Monotonic Increasing Stack
- "Largest Rectangle in Histogram" → Monotonic Increasing Stack
- "Stock Span Problem" → Monotonic Decreasing Stack
- O(N²) brute force is obvious → think Monotonic Stack for O(N)

---

## 📐 Template

```python
def next_greater(arr):
    result = [-1] * len(arr)
    stack = []  # stores indices

    for i in range(len(arr)):
        # Pop all elements whose "next greater" is arr[i]
        while stack and arr[stack[-1]] < arr[i]:
            idx = stack.pop()
            result[idx] = arr[i]
        stack.append(i)

    return result  # remaining in stack have no next greater → -1
```

**Key:** Store **indices** not values, so you can compute distances/spans.

---

## 📝 Canonical Problems

| Problem | Stack Order | What pops |
|---------|-------------|-----------|
| Next Greater Element | Decreasing | When arr[i] > stack top |
| Daily Temperatures | Decreasing | When temp[i] > stack top |
| Previous Smaller Element | Increasing | When arr[i] < stack top |
| Largest Rectangle in Histogram | Increasing | When arr[i] < stack top |
| Trapping Rain Water | Decreasing | When height[i] > stack top |
| Stock Span Problem | Decreasing | When price[i] ≥ stack top |

---

## 🔥 The SDE-2 Differentiator — Trapping Rain Water

> Most SDE-1 candidates give only the two-pointer approach.
> An SDE-2 candidate explains **both** and articulates the trade-off.

**Two-pointer approach:** O(N) time, O(1) space — track max from left and right.
**Monotonic stack approach:** O(N) time, O(N) space — compute water level at each "valley".

Same time complexity, different implementation philosophy. Knowing both shows depth.

---

## 📊 Complexity

| | Time | Space |
|---|------|-------|
| All problems | O(N) amortized | O(N) |

**Why O(N)?** Each element is pushed once and popped once → 2N operations total.

---

## 🚨 Edge Cases

```
1. Empty array → return []
2. All decreasing → stack never pops, all -1
3. All same values → depends on strict vs non-strict inequality in condition
4. Single element → return [-1] or [0]
```
