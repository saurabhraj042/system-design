# 🧩 Pattern 10 — Dynamic Programming

**Tier:** 🟠 Tier 2 — Deep Knowledge Required
**Frequency:** Google ⭐⭐⭐⭐⭐ | Amazon ⭐⭐⭐⭐ | Meta ⭐⭐⭐⭐

---

## 🧠 Core Intuition

Break a problem into **overlapping subproblems** with **optimal substructure**.
- Overlapping: same subproblems appear multiple times
- Optimal substructure: optimal answer to big problem uses optimal answers to subproblems

---

## 🔍 Pattern Recognition Triggers

- "Count the number of ways to..."
- "Find the maximum/minimum..."
- "Can we achieve X?"
- "What is the longest/shortest..."
...with **choices** at each step that depend on previous decisions.

---

## 📐 The 4-Step DP Framework

```
Step 1: Define state   — What does dp[i] (or dp[i][j]) represent?
Step 2: Recurrence     — How does dp[i] relate to dp[i-1], dp[i-2], etc.?
Step 3: Base case      — What's the trivial answer? (dp[0], dp[1])
Step 4: Direction      — Top-down (memoization) or bottom-up (tabulation)?
```

---

## 🗂️ The 6 DP Archetypes

### 1. Linear DP
```
dp[i] depends on dp[i-1] or dp[i-2]
Problems: Fibonacci, Climbing Stairs, House Robber
```

### 2. Knapsack
```
dp[i][w] = max value using first i items with capacity w
Problems: 0/1 Knapsack, Coin Change, Partition Equal Subset Sum
```

### 3. String DP (Two Sequences)
```
dp[i][j] = answer for s1[0..i] and s2[0..j]
Problems: LCS, Edit Distance, Longest Palindromic Subsequence
```

### 4. Grid DP
```
dp[i][j] = answer to reach cell (i,j)
Problems: Unique Paths, Minimum Path Sum, Dungeon Game
```

### 5. Interval DP
```
dp[i][j] = answer for subarray from i to j
Problems: Burst Balloons, Matrix Chain Multiplication, Palindrome Partitioning
```

### 6. DP on Trees
```
dp[node] = answer for subtree rooted at node (post-order DFS)
Problems: Diameter of Binary Tree, Binary Tree Maximum Path Sum
```

---

## 🔥 The DP + Binary Search Combo (SDE-2 Critical)

Real Amazon SDE-2 OA had: "LIS variant — pure DP gives TLE."

**Classic LIS (O(N²)):**
```python
dp[i] = 1 + max(dp[j] for j < i if arr[j] < arr[i])
```

**Optimized LIS (O(N log N)):**
```python
import bisect
tails = []
for num in arr:
    pos = bisect.bisect_left(tails, num)
    if pos == len(tails):
        tails.append(num)
    else:
        tails[pos] = num
return len(tails)
```

The `tails` array maintains the smallest tail for each increasing subsequence length. Binary search finds where to place/replace. This is the insight interviewers look for.

---

## 📝 Must-Know Problems by Archetype

| Archetype | Problem | Key State |
|-----------|---------|-----------|
| Linear | House Robber | dp[i] = max(dp[i-1], dp[i-2]+nums[i]) |
| Knapsack | Coin Change | dp[amount] = min coins |
| String | Edit Distance | dp[i][j] = min ops to convert s1[:i] to s2[:j] |
| Grid | Unique Paths | dp[i][j] = dp[i-1][j] + dp[i][j-1] |
| Interval | Burst Balloons | dp[i][j] = max coins in range (i,j) |
| Tree | Max Path Sum | postorder: return max single path from node |

---

## 🚨 Edge Cases

```
1. Empty input → base case must handle size 0
2. Single element → base case must handle size 1
3. All elements same → verify recurrence still holds
4. Negative values in grid → don't assume minimum is 0
5. Space optimization: if dp[i] only needs dp[i-1], use two variables
```

---

## 📊 Complexity Reference

| Archetype | Time | Space | Optimized Space |
|-----------|------|-------|-----------------|
| Linear DP | O(N) | O(N) | O(1) with two vars |
| Knapsack | O(N×W) | O(N×W) | O(W) with 1D array |
| String DP | O(N×M) | O(N×M) | O(min(N,M)) |
| Grid DP | O(N×M) | O(N×M) | O(M) |
| Interval DP | O(N³) | O(N²) | — |

---

## 🔗 Related Patterns

- DP + [[03 - Binary Search on Answer|Binary Search]] → LIS optimization
- DP on [[09 - Graph BFS DFS Union-Find|Graphs]] → [[14 - Graph DP|Graph DP]]
- DP + [[11 - Backtracking|Backtracking]] → memoized search
