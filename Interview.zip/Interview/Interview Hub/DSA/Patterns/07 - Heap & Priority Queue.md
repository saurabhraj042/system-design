# 🏔️ Pattern 07 — Heap & Priority Queue (Top-K)

**Tier:** 🔴 Tier 1 — Must Master
**Frequency:** Amazon ⭐⭐⭐⭐⭐ | Google ⭐⭐⭐⭐ | Flipkart ⭐⭐⭐⭐
**Amazon special:** LRU → LFU → Median Finder chain is a real Amazon SDE-2 drill

---

## 🧠 Core Intuition

Whenever a problem asks for **"top," "smallest," "most frequent," or "K-th"** elements, think Heap first.

- **Min-heap of size K** → tracks K largest elements (top is smallest of the K largest)
- **Max-heap of size K** → tracks K smallest elements
- **Two heaps** → dynamic median

---

## 🔍 Pattern Recognition Triggers

- "K largest / K smallest / Kth element"
- "Merge K sorted lists/arrays"
- "Find median from a data stream"
- "Top K frequent elements"
- "Task Scheduler" (real Amazon OA problem)

---

## 📐 Top-K Template

```python
import heapq

def top_k_largest(arr, k):
    # Min-heap of size K — top is the K-th largest
    heap = []
    for num in arr:
        heapq.heappush(heap, num)
        if len(heap) > k:
            heapq.heappop(heap)   # Remove smallest
    return list(heap)

# heap[0] is the Kth largest element
```

**Why min-heap for K largest?** We want to *evict* the smallest when we exceed K. Min-heap gives O(1) access to minimum.

---

## 🔥 The Two-Heap Pattern — Median Finder (SDE-2 Favorite)

Favorite at Amazon: tests heap invariant maintenance under dynamic inserts.

```python
class MedianFinder:
    def __init__(self):
        self.low = []   # max-heap (negate for Python) — lower half
        self.high = []  # min-heap — upper half

    def addNum(self, num):
        heapq.heappush(self.low, -num)          # Always push to max-heap first
        heapq.heappush(self.high, -heapq.heappop(self.low))  # Balance

        if len(self.high) > len(self.low):      # Keep low >= high in size
            heapq.heappush(self.low, -heapq.heappop(self.high))

    def findMedian(self):
        if len(self.low) > len(self.high):
            return -self.low[0]
        return (-self.low[0] + self.high[0]) / 2
```

**Invariant:** `len(low) == len(high)` or `len(low) == len(high) + 1`
**Result:** Median is always at the top of one or both heaps — O(1) access.

---

## 📝 Canonical Problems

| Problem | Approach | Complexity |
|---------|----------|------------|
| Kth Largest Element in Array | Min-heap size K | O(N log K) |
| Top K Frequent Elements | HashMap + Min-heap | O(N log K) |
| Merge K Sorted Lists | Min-heap with (val, list_idx) | O(N log K) |
| Find Median from Data Stream | Two heaps | O(log N) add, O(1) find |
| Task Scheduler | Max-heap + cooldown logic | O(N log N) |
| K Closest Points to Origin | Min-heap by distance | O(N log K) |

---

## 📊 Complexity

| Operation | Min/Max Heap |
|-----------|-------------|
| Push | O(log N) |
| Pop | O(log N) |
| Peek (top) | O(1) |
| Build from array | O(N) (heapify) |

**Top-K overall:** O(N log K) — much better than O(N log N) full sort when K << N.

---

## 🚨 Edge Cases

```
1. K > len(array)     → return entire array sorted
2. All elements equal → K-th largest is that element
3. Empty stream       → handle before findMedian() call
4. Python heapq       → only min-heap; negate values for max-heap behavior
5. Integer overflow   → use long in Java for heap keys
```

---

## 🔥 Bar Raiser Follow-Ups

> *"Can you find Kth largest in O(N) average time?"*
> → Yes — Quickselect (partition-based). Average O(N), worst O(N²). Use when K is small and N is huge.

> *"What if elements stream in and you need running median?"*
> → Two-heap approach. This is the only O(log N) per insert solution.
