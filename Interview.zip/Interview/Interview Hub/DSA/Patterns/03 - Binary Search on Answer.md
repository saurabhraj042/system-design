# 🔍 Pattern 03 — Binary Search on Answer Space

**Tier:** 🔴 Tier 1 — Must Master
**Frequency:** Google ⭐⭐⭐⭐⭐ | Amazon ⭐⭐⭐⭐ | Atlassian ⭐⭐⭐⭐

---

## 🧠 Core Intuition

Don't just binary search on a sorted array. Binary search on the **answer itself**.

The key question: *Can I write a function `isValid(mid)` that tells me if a value X is achievable?*

If YES, and if the answer space is **monotonic** (valid answers form a contiguous block), then binary search that space.

**Mental model:**
```
[ F F F F T T T T T ]   ← answer space
              ↑
         find this boundary
```

---

## 🔑 The Template

```python
def solve(arr):
    lo, hi = min_possible_answer, max_possible_answer

    while lo < hi:
        mid = (lo + hi) // 2
        if isValid(mid):
            hi = mid          # Try smaller (minimize)
        else:
            lo = mid + 1      # Need larger

    return lo  # lo == hi at convergence

def isValid(mid):
    # Greedy check: can we achieve answer ≤ mid?
    # This is the core of the problem
    ...
```

---

## 🔬 The DP + Binary Search Combo (SDE-2 Critical)

> Real Amazon SDE-2 OA: "Longest Increasing Subsequence variant — pure DP gives TLE, needs Binary Search optimization."

Classic LIS is O(N²) with DP. The O(N log N) solution uses **patience sorting** — binary search to find the right position in a maintained sorted array.

This combo (DP state + binary search for transition) is what separates SDE-1 from SDE-2 thinking.

---

## 📝 Canonical Problems

| Problem | isValid() logic | Answer Space |
|---------|----------------|--------------|
| Koko Eating Bananas | Can Koko finish all piles at speed mid? | [1, max(piles)] |
| Split Array Largest Sum | Can we split into ≤ m parts with max sum ≤ mid? | [max(arr), sum(arr)] |
| Capacity to Ship Packages in D Days | Can ship all packages in D days with capacity mid? | [max(weights), sum(weights)] |
| Find Minimum in Rotated Sorted Array | Standard binary search variant | — |
| LIS (O(N log N)) | Binary search on patience sort array | — |

---

## 🚨 Edge Cases

```
1. lo and hi boundary setup — be precise, off-by-one kills you
2. isValid() must be deterministic and cheap (O(N) or O(N log N))
3. Integer overflow: mid = lo + (hi - lo) // 2, not (lo + hi) // 2
4. Infinite loop: ensure lo or hi always changes each iteration
```

---

## 🔥 Bar Raiser Insight

> *"How do you know what lo and hi should be?"*

`lo` = smallest possible answer (often 1 or min element)
`hi` = largest possible answer (often sum or max element)

The `isValid(mid)` greedy function is **the real problem**. Once you write it correctly in O(N), binary search wraps around it for free.

---

## 📊 Complexity

| Approach | Time | Space |
|----------|------|-------|
| Binary Search on Answer + O(N) isValid | O(N log(hi - lo)) | O(1) |
| LIS with Binary Search | O(N log N) | O(N) |
