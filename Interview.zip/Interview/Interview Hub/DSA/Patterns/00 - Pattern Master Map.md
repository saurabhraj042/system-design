# 🗺️ DSA Pattern Master Map

> All 18 patterns, their triggers, complexity, and company frequency.
> Source: Real interview experiences from Amazon, Google, Meta, Atlassian (2024–2026)

---

## 🔴 TIER 1 — High Frequency, High Signal

| # | Pattern | Trigger Keywords | Time | Space | Top Companies |
|---|---------|-----------------|------|-------|---------------|
| 1 | [[01 - Sliding Window\|Sliding Window]] | contiguous, substring, subarray, at most K | O(N) | O(K) | Amazon ⭐⭐⭐⭐⭐, Meta ⭐⭐⭐⭐⭐ |
| 2 | [[02 - Two Pointers\|Two Pointers]] | sorted array, pairs, palindrome, partition | O(N) | O(1) | Amazon ⭐⭐⭐⭐⭐, Google ⭐⭐⭐⭐ |
| 3 | [[03 - Binary Search on Answer\|Binary Search on Answer]] | minimize the maximum, maximize the minimum | O(N log N) | O(1) | Google ⭐⭐⭐⭐⭐, Amazon ⭐⭐⭐⭐ |
| 4 | [[04 - Prefix Sum & Difference Array\|Prefix Sum]] | range sum, subarray sum = K, divisible by K | O(N) | O(N) | Amazon ⭐⭐⭐⭐⭐, Meta ⭐⭐⭐⭐ |
| 5 | [[05 - HashMap & Frequency Map\|HashMap]] | count, find if exists, group by, anagram | O(N) avg | O(N) | Amazon ⭐⭐⭐⭐⭐ |
| 6 | [[06 - Monotonic Stack\|Monotonic Stack]] | next greater, previous smaller, largest rectangle | O(N) amortized | O(N) | Amazon ⭐⭐⭐⭐, Meta ⭐⭐⭐⭐ |
| 7 | [[07 - Heap & Priority Queue\|Heap / Top-K]] | K largest, K closest, median, merge K lists | O(N log K) | O(K) | Amazon ⭐⭐⭐⭐⭐ |

---

## 🟠 TIER 2 — Medium Frequency, Deep Knowledge

| # | Pattern | Trigger Keywords | Time | Space |
|---|---------|-----------------|------|-------|
| 8 | [[08 - Tree Traversal Patterns\|Tree Traversal]] | binary tree, BST, path sum, serialize | O(N) | O(H) |
| 9 | [[09 - Graph BFS DFS Union-Find\|Graph BFS/DFS/UF]] | islands, connected components, shortest path | O(V+E) | O(V) |
| 10 | [[10 - Dynamic Programming\|Dynamic Programming]] | count ways, max/min with choices, can we achieve X | Varies | Varies |
| 11 | [[11 - Backtracking\|Backtracking]] | generate all, permutations, N-Queens, Sudoku | O(N!) worst | O(N) |
| 12 | [[12 - Merge Intervals\|Merge Intervals]] | overlapping intervals, scheduling, calendar | O(N log N) | O(N) |
| 13 | [[13 - Trie\|Trie]] | autocomplete, word search, longest prefix | O(L) per op | O(A×N×L) |

---

## 🟡 TIER 3 — Selective Depth, High SDE-2 Signal

| # | Pattern | Trigger Keywords | Time | Space |
|---|---------|-----------------|------|-------|
| 14 | [[14 - Graph DP\|Graph DP]] | longest path in DAG, memoization on graph | O(V+E) | O(V) |
| 15 | [[15 - Bit Manipulation\|Bit Manipulation]] | single number, power of 2, subsets, XOR | O(N) | O(1) |
| 16 | [[16 - Divide and Conquer\|Divide and Conquer]] | count inversions, closest pair, median of two sorted | O(N log N) | O(log N) |
| 17 | [[17 - Greedy\|Greedy]] | scheduling, minimum X to cover Y, activity selection | O(N log N) | O(1) |
| 18 | [[18 - Design-Based DSA\|Design DS]] | LRU cache, insert-delete-getRandom O(1), median finder | Varies | Varies |

---

## 📊 Company × Pattern Frequency Matrix

| Pattern | Amazon | Google | Meta | Atlassian | Flipkart |
|---------|--------|--------|------|-----------|----------|
| Sliding Window | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| Two Pointers | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| Binary Search (Answer) | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Prefix Sum | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| Monotonic Stack | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Heap / Top-K | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| Tree Traversal | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Graph BFS/DFS/UF | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Dynamic Programming | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| Backtracking | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Merge Intervals | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ |
| Trie | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐ |
| Graph DP | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Bit Manipulation | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐ |
| Greedy | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| Design DS (LRU/LFU) | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |

---

## ⚡ Pattern Identification Cheat Sheet

```
Input is sorted array + find pair/triplet   → Two Pointers
Input is array/string + contiguous subarray → Sliding Window
"Find K largest / K smallest"               → Heap
"Minimize the maximum" / "Maximize the min" → Binary Search on Answer
Range sum queries / Subarray sum = K        → Prefix Sum
Count / Exists / Group by                   → HashMap
Next Greater / Previous Smaller             → Monotonic Stack
Tree problem                                → DFS (pre/in/post) or BFS
Graph connectivity / shortest path          → BFS/DFS/Dijkstra/Union-Find
"Count ways" / "Max/Min with choices"       → Dynamic Programming
Generate all combinations / permutations    → Backtracking
Overlapping intervals / scheduling          → Merge Intervals
Prefix / autocomplete / word search         → Trie
Design a cache / O(1) data structure        → Design DS
```
