# 🪟 Pattern 01 — Sliding Window

**Tier:** 🔴 Tier 1 — Must Master
**Frequency:** Amazon ⭐⭐⭐⭐⭐ | Meta ⭐⭐⭐⭐⭐ | Google ⭐⭐⭐⭐
**Covers:** ~15% of all interview problems

---

## 🧠 Core Intuition

Instead of recomputing from scratch for every subarray/substring, **reuse the previous computation** by sliding a window — add one element from the right, remove one from the left.

The key insight: when a problem asks about **contiguous elements** satisfying some condition, you don't need to check every possible window from scratch. You *slide* the window, making each step O(1) instead of O(K).

**Brute force:** O(N × K) — check every window of size K
**Sliding window:** O(N) — slide across once

---

## 🔍 Pattern Recognition Triggers

Ask yourself these questions when you see a new problem:

- Does it involve a **subarray or substring**?
- Does it ask for **longest / shortest / maximum / minimum** of something contiguous?
- Does it use keywords like: *at most K*, *exactly K*, *without repeating*, *consecutive*?

If YES to any → **Think Sliding Window first.**

---

## 📐 Two Flavors

### Flavor 1: Fixed-Size Window
> Window size K is given. Slide it across the array.

**Template:**
```python
def fixed_window(arr, k):
    window_sum = sum(arr[:k])          # Build first window
    max_sum = window_sum

    for i in range(k, len(arr)):
        window_sum += arr[i]           # Add new right element
        window_sum -= arr[i - k]      # Remove old left element
        max_sum = max(max_sum, window_sum)

    return max_sum
```

**When to use:** Problem gives you a fixed window size K.
**Example:** "Maximum sum of K consecutive elements"

---

### Flavor 2: Variable-Size Window (Dynamic)
> Window grows from the right, shrinks from the left based on a validity condition.

**Template:**
```python
def variable_window(arr):
    left = 0
    result = 0
    window_state = {}   # Track what's inside the window

    for right in range(len(arr)):
        # Step 1: Expand — add arr[right] to window
        update(window_state, arr[right])

        # Step 2: Shrink — while window is INVALID, move left pointer
        while not is_valid(window_state):
            remove(window_state, arr[left])
            left += 1

        # Step 3: Record — window is now valid, update result
        result = max(result, right - left + 1)

    return result
```

**When to use:** No fixed size given. You control when to shrink.
**Example:** "Longest substring without repeating characters"

---

## 🔬 The "Exactly K" Trick (SDE-2 Level)

This is the insight that separates SDE-1 from SDE-2 thinking.

> **"Subarrays with exactly K distinct elements"**

You CANNOT do this directly with a sliding window (window can't be "exactly valid").

**The trick:**
```
f(exactly K) = f(at most K) - f(at most K-1)
```

Write one helper function `atMost(k)` that counts subarrays with AT MOST k distinct elements. Then call it twice. This works because "exactly K" = "at most K" minus "at most K-1".

```python
def subarraysWithKDistinct(arr, k):
    return atMost(arr, k) - atMost(arr, k - 1)

def atMost(arr, k):
    left = 0
    count = 0
    freq = {}
    for right in range(len(arr)):
        freq[arr[right]] = freq.get(arr[right], 0) + 1
        while len(freq) > k:
            freq[arr[left]] -= 1
            if freq[arr[left]] == 0:
                del freq[arr[left]]
            left += 1
        count += right - left + 1
    return count
```

**LeetCode:** 992. Subarrays with K Different Integers

---

## 📝 Canonical Problems (Study in This Order)

| # | Problem | Flavor | Difficulty | Key Insight |
|---|---------|--------|------------|-------------|
| 1 | Maximum Average Subarray I | Fixed | Easy | Basic fixed window warmup |
| 2 | Longest Substring Without Repeating Chars | Variable | Medium | HashSet tracks duplicates |
| 3 | Minimum Size Subarray Sum | Variable | Medium | Shrink when sum ≥ target |
| 4 | Longest Substring with At Most K Distinct | Variable | Medium | HashMap counts frequency |
| 5 | Minimum Window Substring | Variable | Hard | Two pointers + need counter |
| 6 | Subarrays with K Different Integers | Variable | Hard | "Exactly K" = atMost(K) - atMost(K-1) |
| 7 | Sliding Window Maximum | Fixed | Hard | Monotonic Deque inside window |

---

## 📊 Complexity Analysis

| Scenario | Time | Space | Why |
|----------|------|-------|-----|
| Fixed window, no auxiliary structure | O(N) | O(1) | Single pass, no DS |
| Variable window with HashMap | O(N) | O(K) | K = distinct elements in window |
| Sliding Window Maximum (deque) | O(N) | O(K) | Each element pushed/popped once |

**Key rule:** If N ≤ 10^5, O(N) is always acceptable. O(N²) will TLE.

---

## 🚨 Edge Cases — Never Miss These

```
1. Empty input array/string                    → return 0 or ""
2. K > len(array)                              → return -1 or handle gracefully
3. All elements are the same                   → window spans entire array
4. Window never becomes valid                  → return 0
5. Answer is the entire array                  → left stays at 0 throughout
6. Negative numbers in sum problems            → sliding window may NOT work
   (use Kadane's / prefix sum instead)
```

> ⚠️ **Bar Raiser trap:** Sliding window does NOT work when array has negative numbers and you're looking for maximum subarray sum. That's Kadane's Algorithm. Always clarify: "Are values guaranteed to be positive?"

---

## 🔥 Bar Raiser Follow-Up Questions

These are real follow-ups asked in SDE-2 interviews:

1. *"What if the array has negative numbers — does your solution still work?"*
   → No. Sliding window assumes that adding an element can only increase the sum. With negatives, shrinking the window might worsen the result. Use Kadane's or prefix sums.

2. *"Can you do Minimum Window Substring in a single pass?"*
   → Yes — the two-pointer approach IS a single pass. Clarify you're not doing multiple scans.

3. *"What's the worst-case number of left-pointer moves?"*
   → O(N). Each element is added once (right moves) and removed once (left moves). Total ops = 2N = O(N).

4. *"How would you extend this to a 2D matrix?"*
   → Fix the top and bottom row boundaries, then apply sliding window on column sums. O(N² × M).

---

## 🧪 Dry Run — Longest Substring Without Repeating Characters

**Input:** `"abcabcbb"`
**Goal:** Find longest substring without repeating characters.

```
s = "abcabcbb"
left = 0, seen = {}, result = 0

right=0: add 'a' → seen={'a':0}           window="a"        len=1  result=1
right=1: add 'b' → seen={'a':0,'b':1}     window="ab"       len=2  result=2
right=2: add 'c' → seen={'a':0,'b':1,'c':2} window="abc"    len=3  result=3
right=3: 'a' already in seen at index 0
         → move left to max(left, 0+1) = 1
         → update seen['a'] = 3
         window="bca"     len=3  result=3
right=4: 'b' already in seen at index 1
         → move left to max(left, 1+1) = 2
         → update seen['b'] = 4
         window="cab"     len=3  result=3
right=5: 'c' already in seen at index 2
         → move left to max(left, 2+1) = 3
         → update seen['c'] = 5
         window="abc"     len=3  result=3
right=6: 'b' already in seen at index 4
         → move left to max(left, 4+1) = 5
         → update seen['b'] = 6
         window="cb"      len=2  result=3
right=7: 'b' already in seen at index 6
         → move left to max(left, 6+1) = 7
         → update seen['b'] = 7
         window="b"       len=1  result=3

Output: 3 ("abc")
```

**Note:** We store the *index* in the map (not just existence) so we can jump `left` directly without sliding one-by-one. This is the O(N) trick vs the naive O(N²) approach.

---

## 💻 Clean SDE-2 Quality Code

```python
def lengthOfLongestSubstring(s: str) -> int:
    """
    Sliding window with character → last index map.
    Time: O(N) — single pass
    Space: O(min(N, A)) where A = alphabet size (26 for lowercase, 128 for ASCII)
    """
    last_seen = {}   # char → last seen index
    left = 0
    result = 0

    for right, char in enumerate(s):
        if char in last_seen and last_seen[char] >= left:
            # Jump left past the duplicate — do NOT just left += 1
            left = last_seen[char] + 1

        last_seen[char] = right
        result = max(result, right - left + 1)

    return result
```

**Why `last_seen[char] >= left`?** Because the duplicate might be from *before* our current window. We only care about duplicates inside the window.

---

## 🔗 Related Patterns

- When window needs a **max/min inside it** → add [[06 - Monotonic Stack|Monotonic Deque]]
- When counting subarrays → combine with [[04 - Prefix Sum & Difference Array|Prefix Sum]]
- When fixed window on matrix → combine with [[04 - Prefix Sum & Difference Array|2D Prefix Sum]]

---

## 📌 My Drill Log

| Date | Problem | Difficulty | Status | Time Taken | Notes |
|------|---------|------------|--------|------------|-------|
| | | | | | |

> See: [[Sliding Window — Problem Drill 01]]
