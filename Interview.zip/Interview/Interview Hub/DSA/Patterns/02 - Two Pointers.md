# 👆👆 Pattern 02 — Two Pointers

**Tier:** 🔴 Tier 1 — Must Master
**Frequency:** Amazon ⭐⭐⭐⭐⭐ | Google ⭐⭐⭐⭐ | Meta ⭐⭐⭐⭐

---

## 🧠 Core Intuition

Use two indices to scan the array intelligently instead of using nested loops. Reduces O(N²) to O(N) or O(N log N) with sort.

---

## 📐 Three Variants

### Variant 1: Opposite Ends (Converging)
Both pointers start at opposite ends and move toward each other.
**Use when:** Sorted array + find pair satisfying condition.

```python
left, right = 0, len(arr) - 1
while left < right:
    if condition(arr[left], arr[right]):
        # record answer
        left += 1; right -= 1
    elif too_small:
        left += 1
    else:
        right -= 1
```

**Problems:** Two Sum (sorted), 3Sum, Container With Most Water, Trapping Rain Water

---

### Variant 2: Same Direction (Fast-Slow)
Both pointers move right, but at different speeds or conditions.
**Use when:** Removing duplicates, partitioning, finding subarrays.

```python
slow = 0
for fast in range(len(arr)):
    if condition(arr[fast]):
        arr[slow] = arr[fast]
        slow += 1
```

**Problems:** Remove Duplicates from Sorted Array, Move Zeroes, Partition Array

---

### Variant 3: Floyd's Cycle Detection (Tortoise & Hare)
One pointer moves 1 step, other moves 2 steps. If they meet → cycle exists.
**Use when:** Linked list cycle detection, finding cycle entry point.

```python
slow = fast = head
while fast and fast.next:
    slow = slow.next
    fast = fast.next.next
    if slow == fast:
        # Cycle detected
        break
```

**Problems:** Linked List Cycle, Find Duplicate Number, Happy Number

---

## 📝 Canonical Problems

| Problem | Variant | Key Insight |
|---------|---------|-------------|
| Two Sum (sorted array) | Opposite Ends | Move left if sum too small, right if too large |
| 3Sum | Opposite Ends | Sort first, fix one element, two-pointer on rest |
| Container With Most Water | Opposite Ends | Move the shorter side — moving taller can't help |
| Trapping Rain Water | Opposite Ends | Water level = min(maxLeft, maxRight) - height[i] |
| Remove Duplicates | Same Direction | Slow pointer = write head |
| Linked List Cycle II | Floyd's | After meeting: reset one to head, move both at speed 1 |

---

## 🚨 Edge Cases

```
1. Array has < 2 elements          → handle before entering loop
2. All elements identical          → depends on problem (duplicates OK?)
3. No valid pair exists            → return -1 or []
4. Negative numbers in sorted arr  → still works, just be careful with products
5. Integer overflow in 3Sum/4Sum   → use long in Java, Python is safe
```

---

## 📊 Complexity

| Variant | Time | Space |
|---------|------|-------|
| Opposite Ends | O(N) after O(N log N) sort | O(1) |
| Same Direction | O(N) | O(1) |
| Floyd's Cycle | O(N) | O(1) |

---

## 🔥 Bar Raiser Insight

> *"For 3Sum, why is O(N²) acceptable and not O(N²log N)?"*

Sorting is O(N log N). The two-pointer scan for each fixed element is O(N). Total = O(N log N + N²) = **O(N²)**. The sort doesn't dominate because N² grows faster.

> *"Why does moving the shorter pointer work in Container With Most Water?"*

Water = min(h[l], h[r]) × (r - l). If you move the taller pointer, min can only stay same or get smaller, and width decreases → result gets worse or equal. Moving the shorter pointer is the only way you might find a better answer.
