# 🚨 LLM-Proof DSA — The 2026 Interview Shift

> **Source:** Amazon OA 2026 analysis (DesiQnA, Feb 2026), LeetCode discuss threads, real candidate experiences
> **Why this matters:** Understanding *how* interviews are changing is as important as knowing the patterns.

---

## The Core Shift

Amazon's Online Assessment pattern has **quietly undergone a major shift** in recent hiring cycles.

**Earlier, candidates could clear OAs through:**
- Standard DSA templates
- Popular LeetCode patterns
- Memorized problem types

**Now, Amazon OA 2026 introduces:**

> **LLM-Proof DSA Questions** — problems designed to test *reasoning ability*, not pattern recognition.

---

## What Makes a Problem "LLM-Proof"?

An LLM-Proof question is not necessarily harder in *implementation* — but harder in *thinking*.

Such problems typically:

✅ Look deceptively simple initially
✅ Hide a mathematical or structural observation
✅ Break brute-force or template approaches
✅ Fail under direct AI-generated solutions
✅ Require discovery of invariants or constraints

**Instead of testing coding speed, they evaluate:**
- Analytical reasoning
- Problem modeling from scratch
- Observation skills
- Evolving constraint understanding

---

## The 4 New Question Types (Amazon OA 2026)

### 1. Prefix & Frequency-Based Problems
Candidates must reason about **evolving prefixes** rather than static arrays.

Challenges involve:
- Partitioning conditions
- Dynamic constraints
- Frequency invariants
- Mathematical divisibility observations

*These appear easy but become complex at scale.*

### 2. Observation-Driven Greedy
Standard greedy templates fail unless the candidate **discovers the correct invariant first**.

The solution emerges only after **reframing the problem** — often from a mathematical lens.

### 3. Graph Problems with Modified Rules
Classic graph problems with added constraints:
- Reusable edges
- Conditional costs
- Traversal restrictions
- Optimization under unusual metrics

Traditional shortest-path intuition alone is insufficient.

### 4. Mathematical / Structural DSA
Combines:
- Number theory
- Prefix reasoning
- Combinatorial observations
- Proof-based logic

**Implementation becomes trivial after the insight.** The insight IS the problem.

---

## Why Strong Candidates Still Fail

> *"Practice hard, unseen DSA problems for OA and interviews, as the pattern is shifting towards non-standard, unseen problems rather than standard influencer DSA sheets — doing only standard questions is not enough for Amazon OA + Interview."*
> — Amazon SDE Intern, 2026 (LeetCode Discuss)

Common preparation mistakes:
- ❌ Solving large numbers of LC Medium problems without depth
- ❌ Memorizing sliding window or DP templates
- ❌ Relying on AI-generated explanations
- ❌ Only doing "popular" problem lists

What succeeds now:
- ✅ Deriving patterns independently from scratch
- ✅ Reasoning under **changing constraints**
- ✅ Identifying hidden mathematical structure
- ✅ Optimizing logically before touching code

---

## The New Interview Reality

> **Amazon now evaluates how you think, not just what you code.**

With AI tools widely accessible, companies have adapted evaluation:
- **Reasoning over recall**
- **Modeling over memorization**
- **Insight over implementation**

---

## The 2026 Problem-Solving Framework

```
Step 1: READ    — Understand constraints (N ≤ 10^5 → O(N log N) max)
Step 2: OBSERVE — What property is special? (sorted? distinct? bounded?)
Step 3: PATTERN — Which of the 18 patterns fits this observation?
Step 4: PROVE   — Why is this pattern correct? (exchange argument for greedy?
                  optimal substructure for DP?)
Step 5: CODE    — Write clean, modular code
Step 6: VERIFY  — Dry run on small input + edge cases
Step 7: OPTIMIZE— Reduce space? One pass instead of two?
```

---

## Constraint → Complexity Cheat Sheet

| Constraint (N) | Max Acceptable Complexity | Approach |
|----------------|--------------------------|----------|
| N ≤ 10 | O(N!) | Backtracking / Brute force |
| N ≤ 20 | O(2^N) | Bitmask DP |
| N ≤ 500 | O(N³) | Interval DP |
| N ≤ 5,000 | O(N²) | Two loops |
| N ≤ 10^5 | O(N log N) | Sort, Heap, Binary Search |
| N ≤ 10^6 | O(N) | Sliding Window, Prefix Sum |
| N ≤ 10^9 | O(log N) | Binary Search on answer |

---

## Links

- [[DSA Master Index]]
- [[2025-2026 Real Interview Experiences]]
- [[00 - Pattern Master Map]]
