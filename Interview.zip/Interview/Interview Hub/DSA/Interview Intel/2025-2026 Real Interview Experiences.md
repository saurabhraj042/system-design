# 📋 Real Interview Experiences — SDE-2 (2024–2026)

> Ground truth from Amazon, Google, Meta, Atlassian candidates.
> Sources: LeetCode Discuss, Medium, GeeksforGeeks, IGotAnOffer, Glassdoor

---

## 🔴 Amazon SDE-2 (L5) — Interview Loop Structure

### Standard Loop (2024–2026)
```
1. OA (Online Assessment)
   → 2 DSA questions (Medium / Hard)
   → System Design scenario questions
   → Leadership Principle questions

2. Loop Rounds (4 total):
   → Coding Round (DSA — 1–2 LC Medium/Hard)
   → LLD Round (Machine Coding — design with extensibility)
   → HLD Round (System Design)
   → Bar Raiser Round (DSA Hard + Leadership Principles)
```

### Real Questions Asked (Amazon SDE-2 Onsite)

| Round | Question | Pattern |
|-------|----------|---------|
| DSA R1 | Course Schedule problem | Graph — Topological Sort |
| DSA R1 | Size of largest island in matrix | Graph — DFS/BFS |
| DSA Follow-up | Change 1 sea cell → find largest island | Union-Find |
| DSA R2 | Connect nodes at same level in binary tree | Tree — BFS Level Order |
| DSA R2 | Climbing Stairs variant (DP) | Dynamic Programming |
| LLD | Design Snake and Ladder (extensible to other games) | OOD + Design Patterns |
| LLD | Design Stack Overflow | Entities + REST APIs |
| LLD | Design Online Coding Platform (like LeetCode) | OOD + API Design |
| HLD | Design Video Streaming Service (like Netflix/Prime) | HLD — CDN + Storage |
| Bar Raiser | Alice & Bob game with array (Greedy/Math) | Observation-Driven |

### Key Insights from Real Candidates

> *"I was expected to write all classes and code with extensibility in mind. Use suitable design patterns to make your design adaptable."*

> *"Aim to solve two DSA problems within the 1-hour timeframe. Don't spend too long on the first one."*

> *"Don't ignore Leadership Principles — they carry more weight than you might expect. Ask HR for the specific LPs for each round."*

> *"The Bar Raiser asked two hard questions when LP answers were weak — use LP as your safety net."*

---

## 🟠 Amazon OA Pattern Shift (2026)

> From LeetCode Discuss (2026): *"Practice hard, unseen DSA problems. The pattern is shifting towards non-standard, unseen problems — standard influencer DSA sheets are not enough."*

**What changed in 2026 OA:**
- More observation-heavy mathematical problems
- Graph problems with modified traversal rules
- Prefix + frequency combination problems
- Problems where discovering the invariant IS the solve

See: [[LLM-Proof DSA — The 2026 Shift]]

---

## 🟡 SDE-2 Bar Raiser — What It Actually Is

> *"Bar Raisers get special training to make sure Amazon's hiring standards stay high and don't degrade over time. They are a big barrier between you and the job offer. You will NOT be informed which interviewer occupies this role."*
> — IGotAnOffer, July 2025

**Bar Raiser characteristics:**
- Not associated with the team you're applying for
- Focuses on overall candidate quality, not team fit
- Can veto even if all other rounds are positive
- Tests whether you raise or lower the bar relative to current employees

**Common Bar Raiser patterns:**
- Asks harder DSA (LC Hard when you expect LC Medium)
- Probes deeply on LP answers: "Tell me more. What was your specific contribution?"
- Challenges your design decisions: "What if requirements change to X?"

---

## 🔵 Google SDE-2 — What's Different

- **Speed matters more at Meta; depth matters more at Google**
- Google favors graph DP, advanced binary search, and creative DP problems
- Coding rounds: expect full working code, not pseudocode
- System design: emphasize distributed systems, CAP theorem, consistency models

---

## 📊 What Interviewers Actually Signal On

| Signal | SDE-1 Answer | SDE-2 Answer |
|--------|-------------|-------------|
| Pattern identification | 3–5 min | < 2 min |
| Complexity analysis | After coding | Before coding |
| Edge cases | When prompted | Proactively |
| Follow-up | Struggles | Anticipates |
| Trade-offs | "This is the solution" | "Here's option A vs B because..." |
| Scalability | Not mentioned | Built into initial design |

---

## ✅ Green Signals (SDE-2 Hire)

- Identifies pattern in under 2 minutes and explains *why* it applies
- States Time + Space complexity before writing a single line
- Proactively raises edge cases (empty input, overflow, extreme scale)
- Offers an alternative approach and explains trade-offs
- Writes clean, modular code with meaningful variable names
- Handles interviewer's follow-up questions without getting flustered

## ❌ Red Flags (No Hire)

- Jumps to code without clarifying constraints
- Hardcodes array sizes or magic numbers
- Only gives one solution without comparing trade-offs
- Implements O(N²) when O(N log N) is expected
- Cannot explain why their approach is correct
- Panics when asked a follow-up variation

---

## 📚 Resources Recommended by Successful Candidates

| Resource | Best For |
|----------|----------|
| NeetCode.io | Pattern-organized problem lists with video explanations |
| LeetCode Premium (Amazon/Google tags) | Company-specific recent questions |
| Grokking the Coding Interview | Pattern-based learning (not just answers) |
| Blind 75 / Grind 75 | Curated high-yield problem sets |
| ByteByteGo | System design visual explanations |
| Alex Xu System Design books | HLD deep dives |
| Gaurav Sen (YouTube) | System design explanations |
| Shreyas Jain (YouTube/Udemy) | LLD + Design Patterns |

---

## 🔗 Links

- [[DSA Master Index]]
- [[LLM-Proof DSA — The 2026 Shift]]
- [[00 - Pattern Master Map]]
